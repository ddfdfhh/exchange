"use strict";
exports.id = 916;
exports.ids = [916];
exports.modules = {

/***/ 5916:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   H1: () => (/* binding */ MakeGetRequestNoQuery),
/* harmony export */   JO: () => (/* binding */ MakePostRequest),
/* harmony export */   U7: () => (/* binding */ MakePostRequestFormData),
/* harmony export */   lA: () => (/* binding */ MakeGetRequestRemoteQuery),
/* harmony export */   v9: () => (/* binding */ MakePostRequestUrl)
/* harmony export */ });
/* unused harmony export MakeGetRequestWithQuery */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(40248);

const MakePostRequest = (params, base_url, token)=>{
    if (token !== undefined) {
        return axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.post("http://localhost:4000/" + base_url, params, {
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + token
            }
        });
    } else {
        return axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.post("http://localhost:4000/" + base_url, params, {
            headers: {
                "Content-Type": "application/json"
            }
        });
    }
};
const MakePostRequestFormData = (params, base_url, token)=>{
    axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.defaults.headers.common["Authorization"] = "Bearer " + token;
    return axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.post("http://localhost:4000/" + base_url, params, {
        headers: {
            "Content-Type": "multipart/form-data",
            "Authorization": "Bearer " + token
        }
    });
};
const MakePostRequestUrl = (params, url, token)=>{
    return axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.post(url, params, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + token
        }
    });
};
const MakeGetRequestWithQuery = (parameters, base_url, token)=>{
    let qs = "";
    for(var key in parameters){
        let value = parameters[key];
        qs += encodeURIComponent(key) + "=" + encodeURIComponent(value) + "&";
    }
    return axios.get("http://localhost:4000/" + base_url + "?" + qs, {
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + token
        }
    });
};
const MakeGetRequestNoQuery = (url, token)=>{
    axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.defaults.headers.common["Authorization"] = "Bearer " + token;
    return axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.get("http://localhost:4000/" + url);
};
const MakeGetRequestRemoteQuery = (params, url)=>{
    //  axios.defaults.headers.common["Authorization"] = 'Bearer '+token;
    return axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.get(url, params);
};



/***/ })

};
;