exports.id = 873;
exports.ids = [873];
exports.modules = {

/***/ 62940:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ OrderBook)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* eslint-disable*/ /* __next_internal_client_entry_do_not_use__ default auto */ 

let authToken;
const isBrowser = (/* unused pure expression or super */ null && ("undefined" !== "undefined"));
let ws;
function OrderBook(props) {
    const [depth, setDepth] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("10");
    const [wsInstance, setWsInstance] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [bid, updateBid] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [ask, updateAsk] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    // useEffect(() => {
    //     console.log('inteval changed')
    //     updateData(data => []);
    // }, [interval])
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        updateBid((bid)=>[]);
        updateAsk((ask)=>[]);
        // const url = `https://testnet.binance.vision/api/v3/klines?symbol=BTCUSDT&interval=${interval}&limit=100`
        const url = `https://api.binance.com/api/v3/depth?limit=10&symbol=${props.coin}USDT`;
    /* MakeGetRequestNoQuery(url, authToken)
            .then((res: any) => {

                updateBid(bid => [...res['data']['bids']])
                updateAsk(bid => [...res['data']['asks']])

                if (isBrowser) {
                    ws = new WebSocket('wss://stream.binance.com:9443/ws');
                    ws.onopen = function () {
                        ws.send(JSON.stringify(
                            {
                                "method": "SUBSCRIBE",
                                "params": [
                                    "bnbusdt@depth5"

                                ],
                                "id": 12
                            }
                        ))
                        console.log("Connection opened...");
                    };

                    ws.onmessage = function (event: any) {
                        const r = JSON.parse(event.data);
                        console.log('socket bids', r['bids'])
                        if (r['result'] === undefined) {


                            updateBid(bid => [...r['bids']])
                            updateAsk(bid => [...r['asks']])
                        }
                    };

                    ws.onclose = function () {
                        console.log("Connection closed...");
                    };



                }
            })



        return () => {

            if (ws?.readyState !== 3)
                ws.close(1000, 'unknown')


        }
        */ }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "card-body",
            style: {
                paddingLeft: "1px"
            },
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "tab-content",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "tab-pane fade show active",
                    id: "Both",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                            id: "priceTableup",
                            className: "priceTable table table-hover custom-table-2 table-bordered align-middle mb-0",
                            style: {
                                width: "100%"
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Price(USDT)"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Amount(BTC)"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Total"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                    children: bid.map((v)=>{
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "color-price-up",
                                                        children: parseFloat(v[0]).toFixed(5)
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    children: parseFloat(v[1]).toFixed(5)
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    children: (v[0] * v[1]).toFixed(5)
                                                })
                                            ]
                                        });
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                            id: "priceTabledown",
                            className: "priceTable table table-hover custom-table-2 table-bordered align-middle mb-0",
                            style: {
                                width: "100%"
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Price(USDT)"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Amount(BTC)"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                children: "Total"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                    children: ask.map((v)=>{
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "color-price-down",
                                                        children: parseFloat(v[0]).toFixed(5)
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    children: parseFloat(v[1]).toFixed(5)
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    children: (v[0] * v[1]).toFixed(5)
                                                })
                                            ]
                                        });
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
}


/***/ }),

/***/ 58705:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   v: () => (/* binding */ Ticker)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _util_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59495);


function Ticker(props) {
    const ticker = props.ticker;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "d-flex",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "d-flex flex-column mx-4 flex-fill",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            className: "text-danger font-bold",
                            children: [
                                (0,_util_helpers__WEBPACK_IMPORTED_MODULE_1__/* .formatDecimal */ .VG)(ticker.lastPrice),
                                "\xa0",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "icofont-arrow-down"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            className: "text-danger font-bold",
                            children: [
                                "$",
                                (0,_util_helpers__WEBPACK_IMPORTED_MODULE_1__/* .formatDecimal */ .VG)(ticker.lastPrice),
                                " \xa0",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "icofont-arrow-down"
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "d-flex flex-column mx-4 flex-fill",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                        children: "24h Change"
                    }),
                    parseFloat(ticker.priceChangePercent) < 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text-danger mr-2",
                                children: [
                                    (0,_util_helpers__WEBPACK_IMPORTED_MODULE_1__/* .formatDecimal */ .VG)(ticker.lastPrice),
                                    " \xa0",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "icofont-long-arrow-down"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text-danger",
                                children: [
                                    ticker.priceChangePercent,
                                    "% \xa0",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "icofont-long-arrow-down"
                                    })
                                ]
                            })
                        ]
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text-success mr-2",
                                children: [
                                    (0,_util_helpers__WEBPACK_IMPORTED_MODULE_1__/* .formatDecimal */ .VG)(ticker.lastPrice),
                                    " \xa0",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "icofont-long-arrow-up"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text-success",
                                children: [
                                    ticker.priceChangePercent,
                                    "% \xa0",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "icofont-long-arrow-up"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "d-flex flex-column mx-4 flex-fill",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                        children: "24h High"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "",
                        children: (0,_util_helpers__WEBPACK_IMPORTED_MODULE_1__/* .formatDecimal */ .VG)(ticker.highPrice)
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "d-flex flex-column mx-4 flex-fill",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                        children: "24h Low"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "",
                        children: (0,_util_helpers__WEBPACK_IMPORTED_MODULE_1__/* .formatDecimal */ .VG)(ticker.lowPrice)
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "d-flex flex-column mx-4 flex-fill",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("b", {
                        children: [
                            "24h Volume(",
                            props.mainCurrency,
                            ")"
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "",
                        children: (0,_util_helpers__WEBPACK_IMPORTED_MODULE_1__/* .formatDecimal */ .VG)(ticker.volume)
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "d-flex flex-column mx-4 flex-fill",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                        children: "24h Volume(USDT)"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "",
                        children: (0,_util_helpers__WEBPACK_IMPORTED_MODULE_1__/* .formatDecimal */ .VG)(ticker.quoteVolume)
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 50910:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ Trade)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* eslint-disable*/ /* __next_internal_client_entry_do_not_use__ default auto */ 

let authToken;
const isBrowser = (/* unused pure expression or super */ null && ("undefined" !== "undefined"));
let ws;
function Trade(props) {
    const [depth, setDepth] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("10");
    const [wsInstance, setWsInstance] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [trades, updateTrades] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        //  updateTrades(trades => []);
        // const url = `https://testnet.binance.vision/api/v3/klines?symbol=BTCUSDT&interval=${interval}&limit=100`
        const url = `https://api.binance.com/api/v3/trades?limit=15&symbol=${props.coin}USDT`;
    /* MakeGetRequestNoQuery(url, authToken).then((res: any) => {
      let res1 = res["data"].map((v: any) => {
        return {
          price: v.price,
          quantity: v["qty"],
          time: v["time"],
          isBuyer: v["isBuyerMaker"],
        };
      });
      res1.sort((a, b) => {
        return b.time - a.time;
      });
      updateTrades((trades) => [...res1]);
      console.log("inside api afiani");
      if (isBrowser) {
        ws = new WebSocket("wss://stream.binance.com:9443/ws");
        ws.onopen = function () {
          ws.send(
            JSON.stringify({
              method: "SUBSCRIBE",
              params: ["bnbusdt@trade"],
              id: 12,
            })
          );
          console.log("Connection opened...");
        };

        ws.onmessage = function (event: any) {
          const r = JSON.parse(event.data);

          if (r["result"] === undefined) {
            let g = {
              price: r["p"],
              quantity: r["q"],
              time: r["T"],
              isBuyer: r["m"],
            };

            updateTrades((trades) => [g, ...trades]);
          }
        };

        ws.onclose = function () {
          console.log("Connection closed...");
        };
      }
    });

    return () => {
      if (ws?.readyState !== 3) ws.close(1000, "unknown");
    };*/ }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (trades.length > 14) {
            trades.pop();
            updateTrades((trades)=>[
                    ...trades
                ]);
        }
    }, [
        trades
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "card-body",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                id: "priceTabledown",
                className: "priceTable table table-hover  align-middle mb-0",
                style: {
                    width: "100%"
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                    children: "Price(USDT)"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                    children: "Qty(BTC)"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                    children: "Time"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                        children: trades.map((v)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: `color-price-${!v["isBuyer"] ? "up" : "down"}`,
                                            children: parseFloat(v["price"]).toFixed(5)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: parseFloat(v["quantity"]).toFixed(5)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: new Date(v["time"]).getDate() == new Date().getDate() ? new Date(v["time"]).getHours() + ":" + new Date(v["time"]).getMinutes() + ":" + new Date(v["time"]).getSeconds() : new Date(v["time"]).getFullYear() + "/" + new Date(v["time"]).getMonth() + "/" + new Date(v["time"]).getDate() + " " + new Date(v["time"]).getHours() + ":" + new Date(v["time"]).getMinutes() + ":" + new Date(v["time"]).getSeconds()
                                    })
                                ]
                            });
                        })
                    })
                ]
            })
        })
    });
}


/***/ }),

/***/ 73944:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(63481)


/***/ })

};
;