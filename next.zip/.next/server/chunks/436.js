exports.id = 436;
exports.ids = [436];
exports.modules = {

/***/ 30457:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 63481, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3280, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 69274, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3349, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 90701, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 71898));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 46446));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 27977, 23))

/***/ }),

/***/ 90724:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./app/globals.css
var globals = __webpack_require__(92817);
// EXTERNAL MODULE: ./node_modules/next/script.js
var script = __webpack_require__(91661);
var script_default = /*#__PURE__*/__webpack_require__.n(script);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21313);
;// CONCATENATED MODULE: ./app/components/partials/header.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`E:\exchange\boottest\app\components\partials\header.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const header = (__default__);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(34834);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./app/components/partials/sidebar.tsx


function Sidebar() {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "sidebar py-2 py-md-2 me-0 border-end",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "d-flex flex-column h-100",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    href: "index-2.html",
                    className: "mb-0 brand-icon",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "logo-icon",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "fa fa-gg-circle fs-3"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "logo-text",
                            children: "Cryptoon"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "menu-list flex-grow-1 mt-4 px-1",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                className: "m-link active",
                                href: "/backend",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        x: "0px",
                                        y: "0px",
                                        width: "24px",
                                        height: "24px",
                                        viewBox: "0 0 38 38",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                xmlns: "http://www.w3.org/2000/svg",
                                                d: "M34,18.756V34H22v-8h-6v8h-4V14.31l7-3.89L34,18.756z M34,16.472V6h-6v7.139L34,16.472z",
                                                style: {
                                                    fill: "var(--primary-color)"
                                                },
                                                "data-st": "fill:var(--chart-color4);"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                xmlns: "http://www.w3.org/2000/svg",
                                                className: "st0",
                                                d: "M34,14.19V6h-6v2h4v5.08L19,5.86L0.51,16.13l0.98,1.74L19,8.14l17.51,9.73l0.98-1.74L34,14.19z M32,32h-8v-8H14  v8H6V17.653l-2,1.111V34h12v-8h6v8h12V18.764l-2-1.111V32z"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                className: "mb-0",
                                                children: "Dashboard"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("small", {
                                                className: "text-muted",
                                                children: "Analytics Report"
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                href: "/backend/security",
                                className: "m-link",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        x: "0px",
                                        y: "0px",
                                        width: "24px",
                                        height: "24px",
                                        viewBox: "0 0 38 38",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                xmlns: "http://www.w3.org/2000/svg",
                                                d: "M20,25c0-1.698,0-6.334,0-11c0-4.418-1.582-8-6-8c-2.083,0-4.072,0.888-5.538,2.335  C5.708,11.053,4,14.826,4,19c0,8.284,6.716,15,15,15c2.736,0,5.294-0.745,7.503-2.025C22.87,31.719,20,28.698,20,25z",
                                                style: {
                                                    fill: "var(--primary-color)"
                                                },
                                                "data-st": "fill:var(--chart-color4);"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                xmlns: "http://www.w3.org/2000/svg",
                                                className: "st0",
                                                d: "M15,11l-1,0.01c0,0,0,0,0-0.01H15z M22,0.24v2.04C29.95,3.69,36,10.65,36,19c0,4.17-1.52,8.01-4.03,10.97  l-0.02-0.02C30.68,31.22,28.93,32,27,32c-2.79,0-5.2-1.64-6.32-4H24l2-2h-5.92C20.02,25.67,20,25.34,20,25s0.02-0.67,0.08-1H28l2-2  h-9.32c1.12-2.36,3.53-4,6.32-4c1.93,0,3.68,0.78,4.95,2.05l1.41-1.41C31.73,17.01,29.48,16,27,16c-3.91,0-7.25,2.51-8.48,6H16v2  h2.06C18.02,24.33,18,24.66,18,25s0.02,0.67,0.06,1H16v2h2.52c1.23,3.48,4.56,5.99,8.46,6C24.6,35.28,21.88,36,19,36  C9.63,36,2,28.37,2,19c0-6.07,3.2-11.41,8-14.41V6.1C8.24,6.44,6,7.72,6,11c0,2.78,2.64,3.44,4.76,3.97C12.96,15.52,14,15.9,14,17  c0,2.82-2.5,2.99-2.99,3C10.5,19.99,8,19.82,8,17H6c0,3.28,2.24,4.56,4,4.9V24h2v-2.1c1.76-0.341,4-1.62,4-4.9  c0-2.78-2.64-3.44-4.76-3.97C9.04,12.48,8,12.1,8,11c0-2.82,2.5-2.99,3-3c2.81,0,2.99,2.48,3,3h2c0-1.57-0.86-4.42-4-4.91V3.52  C14.13,2.54,16.51,2,19,2c0.34,0,0.67,0.01,1,0.03V0.02C19.67,0.01,19.33,0,19,0C8.52,0,0,8.52,0,19c0,10.48,8.52,19,19,19  c10.48,0,19-8.52,19-19C38,9.54,31.06,1.68,22,0.24z"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                className: "mb-0",
                                                children: "Security"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("small", {
                                                className: "text-muted",
                                                children: "Secure Account"
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                className: "m-link",
                                href: "/exchange",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        x: "0px",
                                        y: "0px",
                                        width: "24px",
                                        height: "24px",
                                        viewBox: "0 0 64 64",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("linearGradient", {
                                                id: "crp_svg",
                                                gradientUnits: "userSpaceOnUse",
                                                x1: "13.876",
                                                y1: "13.876",
                                                x2: "50.1249",
                                                y2: "50.1249",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                        offset: 0,
                                                        className: "st2"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                        offset: 1,
                                                        className: "st3"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("polygon", {
                                                className: "st1",
                                                points: "50,34 50,30 39.465,30 55.517,20.732 53.518,17.269 37.464,26.537 42.732,17.412 39.268,15.412    34,24.536 34,6 30,6 30,24.536 24.732,15.412 21.268,17.413 26.536,26.536 10.483,17.268 8.483,20.732 24.535,30 14,30 14,34    24.537,34 8.483,43.269 10.483,46.732 26.536,37.465 21.268,46.589 24.732,48.589 30,39.464 30,58 34,58 34,39.465 39.268,48.589    42.732,46.589 37.465,37.465 53.517,46.732 55.517,43.269 39.463,34  "
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                className: "st0",
                                                d: "M50,36c-2.209,0-4-1.791-4-4s1.791-4,4-4s4,1.791,4,4S52.209,36,50,36z M36,6c0,2.209-1.791,4-4,4   s-4-1.791-4-4s1.791-4,4-4S36,3.791,36,6z M36,58c0,2.209-1.791,4-4,4s-4-1.791-4-4s1.791-4,4-4S36,55.791,36,58z M18,32   c0-2.209-1.791-4-4-4s-4,1.791-4,4s1.791,4,4,4S18,34.209,18,32z M44.464,18.412c-1.104,1.913-3.552,2.568-5.464,1.464   c-1.914-1.104-2.568-3.551-1.465-5.464c1.105-1.913,3.551-2.569,5.465-1.464C44.912,14.052,45.568,16.499,44.464,18.412z   M11.483,15.536c1.913,1.104,2.569,3.551,1.464,5.464s-3.551,2.568-5.464,1.464S4.915,18.914,6.02,17S9.57,14.432,11.483,15.536z   M56.517,41.536c1.913,1.104,2.568,3.551,1.464,5.464s-3.551,2.569-5.464,1.465S49.948,44.913,51.053,43   S54.604,40.432,56.517,41.536z M25,44.124c-1.913-1.104-4.36-0.448-5.465,1.464c-1.104,1.913-0.448,4.36,1.465,5.465   s4.359,0.448,5.464-1.465C27.568,47.676,26.913,45.229,25,44.124z M26.464,14.412c1.104,1.913,0.448,4.36-1.465,5.464   s-4.359,0.449-5.464-1.464s-0.449-4.359,1.464-5.464S25.359,12.499,26.464,14.412z M7.483,41.536   c1.913-1.104,4.36-0.449,5.465,1.464s0.448,4.36-1.465,5.465C9.571,49.569,7.125,48.913,6.02,47S5.57,42.641,7.483,41.536z   M52.517,15.536c1.913-1.104,4.359-0.449,5.464,1.464s0.45,4.36-1.463,5.464s-4.36,0.448-5.465-1.465S50.604,16.641,52.517,15.536z   M39,44.124c-1.914,1.104-2.568,3.552-1.465,5.465s3.552,2.568,5.465,1.464s2.568-3.552,1.463-5.465   C43.359,43.676,40.912,43.02,39,44.124z M38,32c0,3.313-2.687,6-6,6s-6-2.687-6-6s2.687-6,6-6S38,28.687,38,32z"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                className: "mb-0",
                                                children: "Exchange"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("small", {
                                                className: "text-muted",
                                                children: "Market CryptoPrice"
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                className: "m-link",
                                href: "ico.html",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        x: "0px",
                                        y: "0px",
                                        width: "24px",
                                        height: "24px",
                                        viewBox: "0 0 64 64",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                className: "st1",
                                                d: "M20,57.921c-0.37,0-0.741-0.096-1.072-0.288L6.071,50.206C5.408,49.823,5,49.116,5,48.352V33.506   c0-0.765,0.409-1.473,1.071-1.856l12.857-7.422c0.663-0.383,1.479-0.383,2.143,0l12.856,7.422C34.592,32.033,35,32.741,35,33.506   v14.846c0,0.765-0.408,1.472-1.072,1.854l-12.856,7.427C20.741,57.825,20.37,57.921,20,57.921z M11,46.125l9,5.198l9-5.198V35.732   l-9-5.194l-9,5.194V46.125z M44,57.919c-0.371,0-0.739-0.096-1.072-0.287L30.071,50.21C29.409,49.827,29,49.12,29,48.352V33.508   c0-0.765,0.408-1.473,1.071-1.856l12.857-7.427c0.664-0.383,1.48-0.383,2.145,0l12.855,7.427C58.592,32.035,59,32.743,59,33.508   v14.844c0,0.769-0.408,1.476-1.072,1.858l-12.855,7.422C44.739,57.823,44.371,57.919,44,57.919z M35,46.125l9,5.196l9-5.196V35.732   l-9-5.198l-9,5.198V46.125z M32,37.135c-0.371,0-0.739-0.096-1.072-0.287l-12.856-7.422C17.409,29.042,17,28.335,17,27.567V12.724   c0-0.766,0.408-1.474,1.071-1.856L30.928,3.44c0.664-0.383,1.48-0.383,2.145,0l12.855,7.427C46.592,11.25,47,11.958,47,12.724   v14.844c0,0.768-0.408,1.475-1.072,1.858l-12.855,7.422C32.739,37.039,32.371,37.135,32,37.135z M23,25.341l9,5.196l9-5.196V14.948   L32,9.75l-9,5.198V25.341z"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                className: "st0",
                                                d: "M31.997,51.321l-13.926-8.046C17.408,42.893,17,42.184,17,41.419V25.341l13.929-8.044   c0.663-0.383,1.479-0.383,2.144,0L47,25.339v16.08c0,0.765-0.408,1.474-1.072,1.856L31.997,51.321z M23,39.195l9,5.198l9-5.198   V28.802l-9-5.194l-9,5.194V39.195z"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                className: "mb-0",
                                                children: "Ico"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("small", {
                                                className: "text-muted",
                                                children: "Initial Coin Offering"
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                className: "m-link",
                                href: "future-trade.html",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        x: "0px",
                                        y: "0px",
                                        width: "24px",
                                        height: "24px",
                                        viewBox: "0 0 64 64",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                className: "st0",
                                                d: "M21.972,34.25c0-4.906,3.495-8.992,8.13-9.912l-3.492-7.764L14.317,40.282l8.673-1.635   C22.345,37.315,21.972,35.828,21.972,34.25z M41.17,38.647l8.673,1.635L37.55,16.574l-3.491,7.764   c4.635,0.92,8.129,5.006,8.129,9.912C42.188,35.828,41.815,37.315,41.17,38.647z M32.08,26.968c-3.875,0-7.016,3.141-7.016,7.016   c0,3.874,3.141,7.016,7.016,7.016c3.875,0,7.018-3.142,7.018-7.016C39.098,30.109,35.955,26.968,32.08,26.968z"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                className: "st1",
                                                d: "M60.001,32c0.001,15.461-12.539,28-28.003,28C16.538,60,4,47.462,4.001,32.002C3.997,16.537,16.536,4,31.996,4   C47.46,4,60,16.537,60.001,32L60.001,32z M54.001,32C54,19.851,44.144,10,31.996,10c-12.145,0-21.999,9.85-21.995,22.001   C10,44.146,19.852,54,31.998,54C44.146,54,54.002,44.145,54.001,32L54.001,32z"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                className: "mb-0",
                                                children: "Future"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("small", {
                                                className: "text-muted",
                                                children: "Future Trade"
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    type: "button",
                    className: "btn btn-link sidebar-mini-btn text-muted",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "icofont-bubble-right"
                        })
                    })
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./app/provider.tsx

const provider_proxy = (0,module_proxy.createProxy)(String.raw`E:\exchange\boottest\app\provider.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: provider_esModule, $$typeof: provider_$$typeof } = provider_proxy;
const provider_default_ = provider_proxy.default;

const e0 = provider_proxy["NextAuthProvider"];

// EXTERNAL MODULE: ./app/lib/auth.ts
var auth = __webpack_require__(88602);
// EXTERNAL MODULE: ./node_modules/next-auth/index.js
var next_auth = __webpack_require__(24279);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(78875);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(7887);
;// CONCATENATED MODULE: ./app/(home)/backend/layout.tsx










const metadata = {
    title: "Create Next App",
    description: "Generated by create next app"
};
async function RootLayout({ children }) {
    const session = await (0,next_auth.getServerSession)(auth/* authOptions */.L);
    if (session == null || session === undefined) {
        return (0,navigation.redirect)("/auth/login");
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("html", {
        lang: "en",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("head", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("link", {
                    rel: "stylesheet",
                    href: "/assets/css/cryptoon.style.min.css"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("body", {
                suppressHydrationWarning: true,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    id: "cryptoon-layout",
                    className: "theme-blue",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(Sidebar, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "main px-lg-4 px-md-4",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(e0, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(header, {
                                        session: session
                                    }),
                                    children
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                src: "/assets/bundles/libscripts.bundle.js"
            })
        ]
    });
}


/***/ }),

/***/ 92817:
/***/ (() => {



/***/ })

};
;