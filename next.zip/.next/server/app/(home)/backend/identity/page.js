(() => {
var exports = {};
exports.id = 694;
exports.ids = [694];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 86819:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 63477:
/***/ ((module) => {

"use strict";
module.exports = require("querystring");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 36203:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(home)',
        {
        children: [
        'backend',
        {
        children: [
        'identity',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 53331)), "E:\\exchange\\boottest\\app\\(home)\\backend\\identity\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 90724)), "E:\\exchange\\boottest\\app\\(home)\\backend\\layout.tsx"],
          
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["E:\\exchange\\boottest\\app\\(home)\\backend\\identity\\page.tsx"];
    
    const originalPathname = "/(home)/backend/identity/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 57256:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 71155))

/***/ }),

/***/ 71155:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Identity)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./app/components/error_alert.tsx
var error_alert = __webpack_require__(98316);
// EXTERNAL MODULE: ./app/components/success_alert.tsx
var success_alert = __webpack_require__(10445);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/formik/dist/index.js
var dist = __webpack_require__(6135);
// EXTERNAL MODULE: ./node_modules/react-html5-camera-photo/build/index.js
var build = __webpack_require__(55783);
var build_default = /*#__PURE__*/__webpack_require__.n(build);
// EXTERNAL MODULE: ./node_modules/react-html5-camera-photo/build/css/index.css
var css = __webpack_require__(23891);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(69232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
;// CONCATENATED MODULE: ./app/components/image_preview.tsx



const ImagePreview = ({ dataUri, isFullscreen })=>{
    let classNameFullscreen = isFullscreen ? "demo-image-preview-fullscreen" : "";
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "demo-image-preview " + classNameFullscreen,
        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
            src: dataUri
        })
    });
};
ImagePreview.propTypes = {
    dataUri: (prop_types_default()).string,
    isFullscreen: (prop_types_default()).bool
};
/* harmony default export */ const image_preview = (ImagePreview);

;// CONCATENATED MODULE: ./app/components/take_photo.tsx





function TakePhoto(props) {
    const [dataUri, setDataUri] = (0,react_.useState)("");
    const [start, setStart] = (0,react_.useState)(false);
    function handleTakePhoto(dataUri) {
        props.sendDataUri(dataUri);
        setDataUri(dataUri);
    }
    const handleStartButton = ()=>{
        setDataUri("");
        if (dataUri.length > 0) {
            setDataUri("");
            setStart(true);
        } else {
            setDataUri("");
            setStart(!start);
        }
    };
    const handleSubmit = ()=>{
    /***submti with datauri got */ };
    const isFullscreen = false;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            dataUri ? /*#__PURE__*/ jsx_runtime_.jsx(image_preview, {
                dataUri: dataUri,
                isFullscreen: isFullscreen
            }) : start && /*#__PURE__*/ jsx_runtime_.jsx((build_default()), {
                onTakePhotoAnimationDone: handleTakePhoto,
                isFullscreen: isFullscreen
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex flex-row justify-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                    onClick: handleStartButton,
                    className: "d-flex btn btn-primary",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "icofont-camera"
                        }),
                        " ",
                        !start ? "Start" : dataUri.length > 0 ? "Restart" : "Stop",
                        " Camera"
                    ]
                })
            }),
            dataUri.length > 0 && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex flex-row justify-center mt-2",
                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    onClick: handleSubmit,
                    children: "Submit"
                })
            })
        ]
    });
}

// EXTERNAL MODULE: ./app/util/make_post_request.ts
var make_post_request = __webpack_require__(5916);
// EXTERNAL MODULE: ./node_modules/next-auth/react/index.js
var react = __webpack_require__(63370);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
;// CONCATENATED MODULE: ./app/(home)/backend/identity/page.tsx
/*eslint-disable*/ /* __next_internal_client_entry_do_not_use__ default auto */ 








let authToken;
function Identity() {
    const { status, data: session } = (0,react.useSession)();
    (0,react_.useEffect)(()=>{
        if (status == "authenticated") {
            authToken = session?.user?.accessToken;
            console.log("token", authToken);
        } else if (status == "unauthenticated") {
            return (0,navigation.redirect)("auth/login");
        }
    }, [
        status
    ]);
    const [current, setCurrent] = (0,react_.useState)(1);
    const [loading, setLoading] = (0,react_.useState)(false);
    const [govIdFront, setGovIdFront] = (0,react_.useState)();
    const [govIdBack, setGovIdBack] = (0,react_.useState)();
    const [panImage, setPanImage] = (0,react_.useState)();
    const [select, setSelect] = (0,react_.useState)();
    const [selfieData, setSelfieData] = (0,react_.useState)();
    const [label, setLabel] = (0,react_.useState)("Government Id Number");
    const [form, setForm] = (0,react_.useState)();
    const [errorAlert, setErrorAlert] = (0,react_.useState)({
        show: false,
        message: ""
    });
    const [successAlert, setSuccessAlert] = (0,react_.useState)({
        show: false,
        message: ""
    });
    (0,react_.useEffect)(()=>{
        if (successAlert.show) setSuccessAlert({
            show: false,
            message: ""
        });
        if (errorAlert.show) setErrorAlert({
            show: false,
            message: ""
        });
    }, [
        errorAlert.show,
        successAlert.show
    ]);
    const showPreviewModal = ()=>{
        const { Modal } = __webpack_require__(13811);
        const myModal = new Modal("#previewModal");
        myModal.show();
    };
    function handleSelectType(val) {
        setSelect(val);
        if (val == "Government Approved Id") setLabel("Approved Id Number");
        else if (val == "Passport") setLabel("Passport Number");
        else if (val == "Driving License") setLabel("Driving License Number");
    }
    console.log("datauri", selfieData);
    function handleSelfieClick(datauri) {
        setSelfieData(datauri);
    }
    function submitDataToServer() {
        const formData = new FormData();
        if (form !== undefined) {
            Object.entries(form).forEach(([key, value])=>{
                if (key == "govIdFront") key = "adhar_front";
                if (key == "govIdBack") key = "adhar_back";
                if (key == "panImage") key = "pan";
                if (value !== undefined) formData.append(key, value);
            });
            if (selfieData !== undefined) {
                // const blob=dataURItoBlob(selfieData)
                formData.append("selfie", selfieData);
            }
            if (authToken !== undefined) {
                console.log("tokken", authToken);
                (0,make_post_request/* MakePostRequestFormData */.U7)(formData, "auth/upload", authToken).then((re)=>{
                    const resp = re.data;
                    if (resp.success) {
                        setSuccessAlert({
                            show: true,
                            message: resp.message
                        });
                    //   redirect('/backend');
                    } else setErrorAlert({
                        show: true,
                        message: resp.message
                    });
                }).catch((err)=>{
                    setErrorAlert({
                        show: true,
                        message: err.message
                    });
                });
            } else setErrorAlert({
                show: true,
                message: "Invalid session"
            });
        }
    }
    function dataURItoBlob(dataURI) {
        var binary = atob(dataURI.split(",")[1]);
        var array = [];
        for(var i = 0; i < binary.length; i++){
            array.push(binary.charCodeAt(i));
        }
        return new Blob([
            new Uint8Array(array)
        ], {
            type: "image/jpeg"
        });
    }
    function getUriFromFile(file) {
        if (file !== undefined) {
            if (true) {
                const objectUrl = URL.createObjectURL(file);
                return /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    alt: "d",
                    src: objectUrl,
                    style: {
                        width: "100px",
                        height: "50px"
                    }
                });
            }
        } else return /*#__PURE__*/ jsx_runtime_.jsx("img", {
            alt: "d",
            src: "",
            style: {
                width: "100px",
                height: "50px"
            }
        });
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "body d-flex py-3",
        children: [
            successAlert.show && /*#__PURE__*/ jsx_runtime_.jsx(success_alert/* default */.Z, {
                message: successAlert.message
            }),
            errorAlert.show && /*#__PURE__*/ jsx_runtime_.jsx(error_alert/* default */.Z, {
                message: errorAlert.message
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container-xxl",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row align-item-center mb-3",
                        children: [
                            status,
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-12",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "card mb-3",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "card-header py-3 d-flex bg-transparent",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                className: "mb-0 fw-bold",
                                                children: "Form Wizard Vertical"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "card-body",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "wizard-main",
                                                id: "w-vertical",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "step-app",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                            className: "step-steps",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                                    "data-step-target": "step1",
                                                                    className: current === 1 ? "active" : "",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            children: "1"
                                                                        }),
                                                                        " Account Information"
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                                    "data-step-target": "step2",
                                                                    className: current === 2 ? "active" : "",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            children: "2"
                                                                        }),
                                                                        " User Information"
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                                    "data-step-target": "step3",
                                                                    className: `${current === 3 ? "active" : ""}`,
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            children: "3"
                                                                        }),
                                                                        " Social ID"
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "step-content",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                    className: `step-tab-panel ${current === 1 ? "active" : ""}`,
                                                                    "data-step": "step1",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(dist.Formik, {
                                                                        onSubmit: (values, { setSubmitting })=>{
                                                                            setForm(values);
                                                                            if (current < 3) setCurrent(current + 1);
                                                                        },
                                                                        initialValues: {
                                                                            fullname: "",
                                                                            email: "",
                                                                            address: "",
                                                                            country: "India"
                                                                        },
                                                                        validate: (values)=>{
                                                                            const errors = {};
                                                                            if (!values.fullname) {
                                                                                errors.fullname = "Required";
                                                                            }
                                                                            if (!values.email) {
                                                                                errors.email = "Required";
                                                                            } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)) {
                                                                                errors.email = "Invalid email address";
                                                                            }
                                                                            if (!values.address) {
                                                                                errors.address = "Required";
                                                                            }
                                                                            return errors;
                                                                        },
                                                                        children: ({ isSubmitting, submitForm })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                                                                children: [
                                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                        className: "row",
                                                                                        children: [
                                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                                className: "col-md-6 col-12 mb-3",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                                                        className: "col-form-label",
                                                                                                        children: "Full Name"
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx(dist.Field, {
                                                                                                        type: "text",
                                                                                                        name: "fullname",
                                                                                                        children: ({ field, meta: { touched, error } })=>/*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                                                                className: `form-control ${touched && error ? "is-invalid" : ""} `,
                                                                                                                ...field
                                                                                                            })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx(dist.ErrorMessage, {
                                                                                                        name: "fullname",
                                                                                                        children: (msg)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                                                className: "text-danger",
                                                                                                                children: msg
                                                                                                            })
                                                                                                    })
                                                                                                ]
                                                                                            }),
                                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                                className: "col-md-6 col-12 mb-3",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                                                        className: "col-form-label",
                                                                                                        children: "Email"
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx(dist.Field, {
                                                                                                        type: "email",
                                                                                                        name: "email",
                                                                                                        placeholder: "Enter email",
                                                                                                        children: ({ field, meta: { touched, error } })=>/*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                                                                className: `form-control ${touched && error ? "is-invalid" : ""} `,
                                                                                                                ...field
                                                                                                            })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx(dist.ErrorMessage, {
                                                                                                        name: "email",
                                                                                                        children: (msg)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                                                className: "text-danger",
                                                                                                                children: msg
                                                                                                            })
                                                                                                    })
                                                                                                ]
                                                                                            }),
                                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                                className: "col-md-6 col-12 mb-3",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                                                        className: "col-form-label",
                                                                                                        children: "Address"
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx(dist.Field, {
                                                                                                        as: "textarea",
                                                                                                        name: "address",
                                                                                                        placeholder: "Enter address",
                                                                                                        children: ({ field, meta: { touched, error } })=>/*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                                                                                                className: `form-control ${touched && error ? "is-invalid" : ""} `,
                                                                                                                ...field
                                                                                                            })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx(dist.ErrorMessage, {
                                                                                                        name: "address",
                                                                                                        children: (msg)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                                                className: "text-danger",
                                                                                                                children: msg
                                                                                                            })
                                                                                                    })
                                                                                                ]
                                                                                            }),
                                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                                className: "col-md-6 col-12 mb-3",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                                                        className: "col-form-label",
                                                                                                        children: "Country"
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("fieldset", {
                                                                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist.Field, {
                                                                                                            as: "select",
                                                                                                            name: "country",
                                                                                                            className: "country form-control form-select",
                                                                                                            "aria-label": "example",
                                                                                                            children: [
                                                                                                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                                                                    children: "Select Country"
                                                                                                                }),
                                                                                                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                                                                    value: "Argentina",
                                                                                                                    children: "Argentina"
                                                                                                                }),
                                                                                                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                                                                    value: "Australia",
                                                                                                                    children: "Australia"
                                                                                                                }),
                                                                                                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                                                                    value: "Belgium",
                                                                                                                    children: "Belgium"
                                                                                                                }),
                                                                                                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                                                                    value: "Brazil",
                                                                                                                    children: "Brazil"
                                                                                                                }),
                                                                                                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                                                                    value: "Canada",
                                                                                                                    children: "Canada"
                                                                                                                }),
                                                                                                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                                                                    value: "Costa Rica",
                                                                                                                    children: "Costa Rica"
                                                                                                                }),
                                                                                                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                                                                    value: "Egypt",
                                                                                                                    children: "Egypt"
                                                                                                                }),
                                                                                                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                                                                    value: "France",
                                                                                                                    children: "France"
                                                                                                                }),
                                                                                                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                                                                    value: "Germany",
                                                                                                                    children: "Germany"
                                                                                                                }),
                                                                                                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                                                                    selected: true,
                                                                                                                    value: "India",
                                                                                                                    children: "India"
                                                                                                                }),
                                                                                                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                                                                    value: "Japan",
                                                                                                                    children: "Japan"
                                                                                                                })
                                                                                                            ]
                                                                                                        })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx(dist.ErrorMessage, {
                                                                                                        name: "country",
                                                                                                        children: (msg)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                                                style: {
                                                                                                                    color: "red",
                                                                                                                    textAlign: "left"
                                                                                                                },
                                                                                                                children: msg
                                                                                                            })
                                                                                                    })
                                                                                                ]
                                                                                            })
                                                                                        ]
                                                                                    }),
                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                        className: "d-flex justify-content-end",
                                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                                                            "data-step-action": "next",
                                                                                            type: "button",
                                                                                            onClick: (e)=>submitForm(),
                                                                                            className: "btn btn-primary step-btn mx-2 my-2",
                                                                                            children: "Next"
                                                                                        })
                                                                                    })
                                                                                ]
                                                                            })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                    className: `step-tab-panel ${current === 2 ? "active" : ""}`,
                                                                    "data-step": "step1",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(dist.Formik, {
                                                                        onSubmit: (values, { setSubmitting })=>{
                                                                            const data = {
                                                                                fullname: form?.fullname,
                                                                                email: form?.email,
                                                                                address: form?.address,
                                                                                country: form?.country,
                                                                                type: values.type,
                                                                                govIdNumber: values.govIdNumber,
                                                                                panNumber: values.panNumber,
                                                                                govIdFront: govIdFront,
                                                                                govIdBack: govIdBack,
                                                                                panImage: panImage
                                                                            };
                                                                            setForm(data);
                                                                            if (current < 3) setCurrent(current + 1);
                                                                        },
                                                                        initialValues: {
                                                                            type: "",
                                                                            govIdNumber: "",
                                                                            panNumber: "",
                                                                            govIdFront: "",
                                                                            govIdBack: "",
                                                                            panImage: ""
                                                                        },
                                                                        validate: (values)=>{
                                                                            const errors = {};
                                                                            if (govIdFront !== undefined) {
                                                                                const govIdSize = govIdFront?.size;
                                                                                const govIdType = govIdFront?.type;
                                                                                if (![
                                                                                    "image/jpeg",
                                                                                    "image/jpg",
                                                                                    "image/gif",
                                                                                    "image/png"
                                                                                ].includes(govIdType)) {
                                                                                    errors.govIdFront = "File type not supported for upload";
                                                                                }
                                                                                if (govIdSize / 1024 / 1024 > 4) {
                                                                                    errors.govIdFront = "File size can not be more than 4MB";
                                                                                }
                                                                            }
                                                                            if (govIdBack !== undefined) {
                                                                                const govIdSize1 = govIdBack?.size;
                                                                                const govIdType1 = govIdBack?.type;
                                                                                if (![
                                                                                    "image/jpeg",
                                                                                    "image/jpg",
                                                                                    "image/gif",
                                                                                    "image/png"
                                                                                ].includes(govIdType1)) {
                                                                                    errors.govIdBack = "File type not supported for upload";
                                                                                }
                                                                                if (govIdSize1 / 1024 / 1024 > 4) {
                                                                                    errors.govIdBack = "File size can not be more than 4MB";
                                                                                }
                                                                            }
                                                                            if (panImage !== undefined) {
                                                                                const govIdSize2 = panImage?.size;
                                                                                const govIdType2 = panImage?.type;
                                                                                if (![
                                                                                    "image/jpeg",
                                                                                    "image/jpg",
                                                                                    "image/gif",
                                                                                    "image/png"
                                                                                ].includes(govIdType2)) {
                                                                                    errors.panImage = "File type not supported for upload";
                                                                                }
                                                                                if (govIdSize2 / 1024 / 1024 > 4) {
                                                                                    errors.panImage = "File size can not be more than 4MB";
                                                                                }
                                                                            }
                                                                            if (!values.type) {
                                                                                errors.type = "Required";
                                                                            }
                                                                            if (!values.panNumber) {
                                                                                errors.panNumber = "Required";
                                                                            }
                                                                            if (!values.govIdNumber) {
                                                                                errors.govIdNumber = "Required";
                                                                            }
                                                                            return errors;
                                                                        },
                                                                        children: ({ isSubmitting, setFieldValue, submitForm })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                                                                children: [
                                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                        className: "row",
                                                                                        children: [
                                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                                className: "col-md-6 col-12 mb-3",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                                                        className: "col-form-label",
                                                                                                        children: "Document Type"
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("fieldset", {
                                                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(dist.Field, {
                                                                                                            as: "select",
                                                                                                            name: "type",
                                                                                                            "aria-label": "example",
                                                                                                            children: ({ field, meta: { touched, error } })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                                                                                                                    name: "type",
                                                                                                                    onChange: (e)=>{
                                                                                                                        setFieldValue("type", e.target.value);
                                                                                                                        handleSelectType(e.target.value);
                                                                                                                    },
                                                                                                                    value: select,
                                                                                                                    className: `form-control form-select ${touched && error ? "is-invalid" : ""} `,
                                                                                                                    children: [
                                                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                                                                            children: "Select "
                                                                                                                        }),
                                                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                                                                            value: "Government Approved Id",
                                                                                                                            selected: select == "Government Approved Id",
                                                                                                                            children: "Any Government Approved Id"
                                                                                                                        }),
                                                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                                                                            value: "Passport",
                                                                                                                            selected: select == "Government Approved Id",
                                                                                                                            children: "Passport"
                                                                                                                        }),
                                                                                                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                                                                            value: "Driving License",
                                                                                                                            selected: select == "Government Approved Id",
                                                                                                                            children: "Driving License"
                                                                                                                        })
                                                                                                                    ]
                                                                                                                })
                                                                                                        })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx(dist.ErrorMessage, {
                                                                                                        name: "type",
                                                                                                        children: (msg)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                                                className: "text-error",
                                                                                                                children: msg
                                                                                                            })
                                                                                                    })
                                                                                                ]
                                                                                            }),
                                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                                className: "col-md-6 col-12 mb-3",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                                                        className: "col-form-label",
                                                                                                        children: label
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx(dist.Field, {
                                                                                                        type: "text",
                                                                                                        name: "govIdNumber",
                                                                                                        placeholder: "Enter  Number",
                                                                                                        children: ({ field, meta: { touched, error } })=>/*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                                                                className: `form-control ${touched && error ? "is-invalid" : ""} `,
                                                                                                                ...field
                                                                                                            })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx(dist.ErrorMessage, {
                                                                                                        name: "govIdNumber",
                                                                                                        children: (msg)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                                                className: "text-danger",
                                                                                                                children: msg
                                                                                                            })
                                                                                                    })
                                                                                                ]
                                                                                            }),
                                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                                className: "col-md-6 col-12 mb-3",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                                                        className: "col-form-label",
                                                                                                        children: "PAN No"
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx(dist.Field, {
                                                                                                        type: "text",
                                                                                                        name: "panNumber",
                                                                                                        placeholder: "Enter PAN Number",
                                                                                                        children: ({ field, meta: { touched, error } })=>/*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                                                                className: `form-control ${touched && error ? "is-invalid" : ""} `,
                                                                                                                ...field
                                                                                                            })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx(dist.ErrorMessage, {
                                                                                                        name: "panNumber",
                                                                                                        children: (msg)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                                                className: "text-danger",
                                                                                                                children: msg
                                                                                                            })
                                                                                                    })
                                                                                                ]
                                                                                            }),
                                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                                className: "col-md-6 col-12 mb-3",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                                                        className: "col-form-label",
                                                                                                        children: "Front"
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx(dist.Field, {
                                                                                                        type: "file",
                                                                                                        name: "govIdFront",
                                                                                                        placeholder: "Enter PAN Number",
                                                                                                        children: ({ field, meta: { touched, error } })=>/*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                                                                className: `form-control ${touched && error ? "is-invalid" : ""} `,
                                                                                                                onChange: (event)=>{
                                                                                                                    if (event?.currentTarget?.files) setGovIdFront(event?.currentTarget?.files[0]);
                                                                                                                },
                                                                                                                type: "file"
                                                                                                            })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx(dist.ErrorMessage, {
                                                                                                        name: "govIdFront",
                                                                                                        children: (msg)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                                                className: "text-danger",
                                                                                                                children: msg
                                                                                                            })
                                                                                                    })
                                                                                                ]
                                                                                            }),
                                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                                className: "col-md-6 col-12 mb-3",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                                                        className: "col-form-label",
                                                                                                        children: "Back Side"
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx(dist.Field, {
                                                                                                        type: "file",
                                                                                                        name: "govIdback",
                                                                                                        placeholder: "Enter PAN Number",
                                                                                                        children: ({ field, meta: { touched, error } })=>/*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                                                                className: `form-control ${touched && error ? "is-invalid" : ""} `,
                                                                                                                onChange: (event)=>{
                                                                                                                    if (event?.currentTarget?.files) setGovIdBack(event?.currentTarget?.files[0]);
                                                                                                                },
                                                                                                                type: "file"
                                                                                                            })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx(dist.ErrorMessage, {
                                                                                                        name: "govIdBack",
                                                                                                        children: (msg)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                                                className: "text-danger",
                                                                                                                children: msg
                                                                                                            })
                                                                                                    })
                                                                                                ]
                                                                                            }),
                                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                                className: "col-md-6 col-12 mb-3",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                                                        className: "col-form-label",
                                                                                                        children: "Pan Card Image"
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx(dist.Field, {
                                                                                                        type: "file",
                                                                                                        name: "panImage",
                                                                                                        placeholder: "Enter PAN Number",
                                                                                                        children: ({ field, meta: { touched, error } })=>/*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                                                                className: `form-control ${touched && error ? "is-invalid" : ""} `,
                                                                                                                onChange: (event)=>{
                                                                                                                    if (event?.currentTarget?.files) setPanImage(event?.currentTarget?.files[0]);
                                                                                                                },
                                                                                                                type: "file"
                                                                                                            })
                                                                                                    }),
                                                                                                    /*#__PURE__*/ jsx_runtime_.jsx(dist.ErrorMessage, {
                                                                                                        name: "panImage",
                                                                                                        children: (msg)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                                                className: "text-danger",
                                                                                                                children: msg
                                                                                                            })
                                                                                                    })
                                                                                                ]
                                                                                            })
                                                                                        ]
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                                        className: "d-flex justify-content-end",
                                                                                        children: [
                                                                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                                                                type: "button",
                                                                                                "data-step-action": "prev",
                                                                                                className: "btn btn-primary step-btn mx-2 my-2",
                                                                                                children: "Prev"
                                                                                            }),
                                                                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                                                                "data-step-action": "next",
                                                                                                type: "button",
                                                                                                onClick: (e)=>submitForm(),
                                                                                                className: "btn btn-primary step-btn mx-2 my-2",
                                                                                                children: "Next"
                                                                                            })
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                    className: `step-tab-panel ${current === 3 ? "active" : ""}`,
                                                                    "data-step": "step1",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx(TakePhoto, {
                                                                            sendDataUri: (data)=>handleSelfieClick(data)
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                            className: "d-flex justify-content-end",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                                                    type: "button",
                                                                                    "data-step-action": "prev",
                                                                                    onClick: ()=>setCurrent(current - 1),
                                                                                    className: "btn btn-primary step-btn mx-2 my-2",
                                                                                    children: "Prev"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                                                    type: "button",
                                                                                    onClick: (e)=>showPreviewModal(),
                                                                                    className: "btn btn-primary step-btn mx-2 my-2",
                                                                                    children: "Save"
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    " "
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal fade rounded-0",
                id: "previewModal",
                tabIndex: -1,
                "aria-hidden": "true",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "modal-dialog rounded-0",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "modal-content rounded-0",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "modal-header",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: "modal-title",
                                        children: "Details Preview"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        type: "button",
                                        className: "btn-close",
                                        "data-bs-dismiss": "modal",
                                        "aria-label": "Close"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "modal-body",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                                    className: "table",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    children: "Full Name"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    children: form?.fullname
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    children: "Email"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    children: form?.email
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    children: "Address"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    children: form?.address
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    children: "Country"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    children: form?.country
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    children: "Id Proof Type"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    children: form?.type
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    children: label
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    children: form?.govIdNumber
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    children: "Pan Number"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    children: form?.panNumber
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    children: "Front Image"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    children: getUriFromFile(form?.govIdFront)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    children: "Back Image"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    children: getUriFromFile(form?.govIdBack)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    children: "Pan Image"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    children: getUriFromFile(form?.panImage)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    children: "Selfie Image"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                        alt: "d",
                                                        src: selfieData,
                                                        width: 50,
                                                        height: 50
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "modal-footer",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        type: "button",
                                        className: "btn btn-secondary",
                                        "data-bs-dismiss": "modal",
                                        children: "Close"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        type: "button",
                                        onClick: (e)=>submitDataToServer(),
                                        className: "btn btn-primary",
                                        children: "Submit For Review"
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
}


/***/ }),

/***/ 53331:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`E:\exchange\boottest\app\(home)\backend\identity\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [763,489,609,977,869,813,967,332,503,232,317,894,528,916,15,602,436], () => (__webpack_exec__(36203)));
module.exports = __webpack_exports__;

})();