(() => {
var exports = {};
exports.id = 531;
exports.ids = [531];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 86819:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 63477:
/***/ ((module) => {

"use strict";
module.exports = require("querystring");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 12787:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(home)',
        {
        children: [
        'backend',
        {
        children: [
        'wallet',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 54001)), "E:\\exchange\\boottest\\app\\(home)\\backend\\wallet\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 90724)), "E:\\exchange\\boottest\\app\\(home)\\backend\\layout.tsx"],
          
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["E:\\exchange\\boottest\\app\\(home)\\backend\\wallet\\page.tsx"];
    
    const originalPathname = "/(home)/backend/wallet/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 92381:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12498))

/***/ }),

/***/ 12498:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Wallet)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/react-qr-code/lib/index.js
var lib = __webpack_require__(34314);
;// CONCATENATED MODULE: ./app/components/QRGenerator.tsx



function QRGenerator(props) {
    console.log("val", props.value);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: props.value && /*#__PURE__*/ jsx_runtime_.jsx("div", {
            style: {
                height: props.height + "px",
                maxWidth: props.width + "px",
                width: "100%"
            },
            children: /*#__PURE__*/ jsx_runtime_.jsx(lib/* default */.Z, {
                style: {
                    height: "auto",
                    maxWidth: "100%",
                    width: "100%"
                },
                value: props.value,
                viewBox: `0 0 ${props.width} ${props.height}`
            })
        })
    });
}

// EXTERNAL MODULE: ./app/util/make_post_request.ts
var make_post_request = __webpack_require__(5916);
// EXTERNAL MODULE: ./app/components/success_alert.tsx
var success_alert = __webpack_require__(10445);
// EXTERNAL MODULE: ./app/components/error_alert.tsx
var error_alert = __webpack_require__(98316);
;// CONCATENATED MODULE: ./app/components/wallet/deposit.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





let adress = "0xded56Cc56381b6192DeD15c35B0043fa15D2E4B8";
const network_options = {
    BTC: [
        {
            value: "Bitcoin",
            label: "Bitcoin"
        }
    ],
    BNB: [
        {
            value: "BEP20",
            label: "Binance Smart Chain BEP20"
        }
    ],
    ETH: [
        {
            value: "Ethereum",
            label: "Ethereum"
        }
    ],
    USDT: [
        {
            value: "BEP20",
            label: "BEP20"
        }
    ],
    DRNH: [
        {
            value: "BEP20",
            label: "Binance Smart Chain"
        }
    ]
};
function Deposit(props) {
    const [copyText, setCopyText] = (0,react_.useState)("Copy");
    const [networks, setNetworks] = (0,react_.useState)([]);
    const [network, setNetwork] = (0,react_.useState)();
    const [coin, setCoin] = (0,react_.useState)();
    const [address, setAddress] = (0,react_.useState)(adress);
    const [memo, setMemo] = (0,react_.useState)();
    const [errorAlert, setErrorAlert] = (0,react_.useState)({
        show: false,
        message: ""
    });
    const [transactions, setTransactions] = (0,react_.useState)([]);
    const [loading, setLoading] = (0,react_.useState)(false);
    const [btnText, setBtnText] = (0,react_.useState)("Confirm");
    const [successAlert, setSuccessAlert] = (0,react_.useState)({
        show: false,
        message: ""
    });
    (0,react_.useEffect)(()=>{
        if (coin !== undefined) {
            console.log("after coin chan", coin);
        }
    }, [
        coin
    ]);
    (0,react_.useEffect)(()=>{
        if (coin !== undefined && network !== undefined) {
            fetchDepositAddress(coin, network).then(async (resp)=>{
                let res = await resp.json();
                setAddress(res["address"]);
                if (res["memo"].length > 0) {
                    setMemo(res["memo"]);
                }
            }).catch((err)=>{
                console.log("err", err);
            });
        }
    }, [
        network
    ]);
    const fetchDepositAddress = (coin, network)=>{
        return fetch("http://localhost:4000/wallet/getAddress", {
            method: "POST",
            headers: {
                "Accept": "application.json",
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                user_id: 1,
                coin: coin,
                network: network
            }),
            cache: "default"
        });
    };
    const handleCoinChange = (e)=>{
        let v = e.target;
        setCoin(v.getAttribute("value"));
        setNetworks(network_options[v.getAttribute("value")]);
    };
    const genrateAddress = ()=>{
        return /*#__PURE__*/ jsx_runtime_.jsx(QRGenerator, {
            value: address,
            width: "50",
            height: "50"
        });
    };
    const generateMemo = ()=>{
        return /*#__PURE__*/ jsx_runtime_.jsx(QRGenerator, {
            value: memo,
            width: "50",
            height: "50"
        });
    };
    const handleCopy = ()=>{
        navigator.clipboard.writeText(address);
        setCopyText("Copied");
    };
    const handleNetworkChange = (e)=>{
        setNetwork(e.currentTarget.value);
    };
    const submitDeposit = ()=>{
        setLoading(true);
        (0,make_post_request/* MakePostRequest */.JO)({
            user_id: 1,
            address,
            coin,
            network
        }, "wallet/deposit", props.token).then(async (resp)=>{
            let res = await resp.json();
            console.log("wtih scc", res);
            if (res["success"]) {
                setBtnText("OK");
                setLoading(false);
            } else {
                setErrorAlert({
                    show: true,
                    message: res["message"]
                });
                setLoading(false);
            }
        }).catch((err)=>{
            setLoading(false);
            console.log("here i", err);
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "card-body",
        children: [
            successAlert.show && /*#__PURE__*/ jsx_runtime_.jsx(success_alert/* default */.Z, {
                message: successAlert.message
            }),
            errorAlert.show && /*#__PURE__*/ jsx_runtime_.jsx(error_alert/* default */.Z, {
                message: errorAlert.message
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "tab-content",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "tab-pane fade show active",
                    id: "crypto",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "mb-3",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        className: "form-label",
                                        children: "Choose Coin"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "row row-cols-3 row-cols-md-3 row-cols-lg-6 row-cols-xl-6",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "col",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "form-check",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            onChange: (val)=>handleCoinChange(val),
                                                            className: "form-check-input",
                                                            type: "radio",
                                                            value: "BTC",
                                                            name: "flexRadioDefault",
                                                            id: "flexRadioDefaultbtc",
                                                            defaultChecked: true
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            className: "form-check-label",
                                                            htmlFor: "flexRadioDefaultbtc",
                                                            children: "BTC"
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "col",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "form-check",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            onChange: (val)=>handleCoinChange(val),
                                                            className: "form-check-input",
                                                            type: "radio",
                                                            value: "ETH",
                                                            name: "flexRadioDefault",
                                                            id: "flexRadioDefaulteth"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            className: "form-check-label",
                                                            htmlFor: "flexRadioDefaulteth",
                                                            children: "ETH"
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "col",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "form-check",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            onChange: (val)=>handleCoinChange(val),
                                                            className: "form-check-input",
                                                            type: "radio",
                                                            name: "flexRadioDefault",
                                                            value: "USDT",
                                                            id: "flexRadioDefaultusdt"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            className: "form-check-label",
                                                            htmlFor: "flexRadioDefaultusdt",
                                                            children: "USDT"
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "col",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "form-check",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            onChange: (val)=>handleCoinChange(val),
                                                            className: "form-check-input",
                                                            type: "radio",
                                                            name: "flexRadioDefault",
                                                            id: "flexRadioDefaultbnb",
                                                            value: "BNB"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                            className: "form-check-label",
                                                            htmlFor: "flexRadioDefaultbnb",
                                                            children: "BNB"
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "mb-3",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        className: "form-label",
                                        children: "Choose Network"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "row",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "col-sm-12",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                    className: "form-label",
                                                    children: "Select Withdraw Network"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                                    className: "form-select",
                                                    "aria-label": "Default select example",
                                                    onChange: (val)=>handleNetworkChange(val),
                                                    children: networks !== undefined && networks.length > 0 ? networks.map((val, i)=>{
                                                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("option", {
                                                            value: val["value"],
                                                            children: [
                                                                " ",
                                                                val["label"],
                                                                "  "
                                                            ]
                                                        }, i);
                                                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("option", {
                                                        value: "",
                                                        className: "bg-transparent hover:bg-transparent",
                                                        children: [
                                                            "Select Network",
                                                            " "
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "mb-3",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        className: "form-label",
                                        children: " Deposit Address"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "row",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "col-md-2",
                                                children: genrateAddress()
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "col-md-8",
                                                children: address
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "col-md-2 ",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    type: "button",
                                                    className: "btn btn-sm  btn-outline-primary",
                                                    onClick: handleCopy,
                                                    children: copyText == "Copied" ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "inline-flex flex-start",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "icofont-ui-copy"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("small", {
                                                                children: "Copied"
                                                            })
                                                        ]
                                                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "d-inline-flex flex-start",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "icofont-ui-copy"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("small", {
                                                                children: "Copy"
                                                            })
                                                        ]
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "mb-3",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "row",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "col-md-6",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "truncated",
                                                    children: "Minimum Deposit"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "text-muted truncated mb-1",
                                                    children: [
                                                        " ",
                                                        "0.0005086 USDT",
                                                        " "
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "col-md-6",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "truncated",
                                                    children: "Expected Arrival"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "text-muted truncated mb-1",
                                                    children: [
                                                        " ",
                                                        "1 network confirm"
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "col-md-6",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "truncated",
                                                    children: "Expected Unlock"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "text-muted truncated",
                                                    children: [
                                                        " ",
                                                        "1 network confirm"
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "mb-3",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    type: "submit",
                                    className: "btn flex-fill btn-light-warning py-2 fs-5 text-uppercase px-5",
                                    children: "Confirm"
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/bitcoin-address-validation/lib/index.cjs.js
var index_cjs = __webpack_require__(69447);
// EXTERNAL MODULE: ./node_modules/react-qr-reader/dist/cjs/index.js
var cjs = __webpack_require__(92232);
;// CONCATENATED MODULE: ./app/components/QRScanner.tsx



function QRScanner(props) {
    const [pl, setPl] = (0,react_.useState)("No result");
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(cjs/* QrReader */.TF, {
            constraints: {
                facingMode: "user"
            },
            onResult: (result, error)=>{
                if (!!result) {
                    setPl(result?.getText);
                    props.onResult1(result?.getText);
                    console.log("scanner", result?.getText);
                }
                if (!!error) {
                    console.info(error);
                }
            },
            containerStyle: {
                padding: "0px!important"
            }
        })
    });
}

;// CONCATENATED MODULE: ./app/components/wallet/withdraw.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 







const withdraw_adress = "0xded56Cc56381b6192DeD15c35B0043fa15D2E4B8";
const withdraw_network_options = {
    BTC: [
        {
            value: "Bitcoin",
            label: "Bitcoin"
        }
    ],
    BNB: [
        {
            value: "BEP20",
            label: "Binance Smart Chain BEP20"
        }
    ],
    ETH: [
        {
            value: "Ethereum",
            label: "Ethereum"
        }
    ],
    USDT: [
        {
            value: "BEP20",
            label: "BEP20"
        }
    ],
    DRNH: [
        {
            value: "BEP20",
            label: "Binance Smart Chain"
        }
    ]
};
function Withdraw(props) {
    const [coin, setCoin] = (0,react_.useState)();
    const [copyText, setCopyText] = (0,react_.useState)("Copy");
    const [networks, setNetworks] = (0,react_.useState)([]);
    const [address, setAddress] = (0,react_.useState)();
    const [loading, setLoading] = (0,react_.useState)(true);
    const [network, setNetwork] = (0,react_.useState)();
    const [message, setMessage] = (0,react_.useState)("");
    const [isValid, setValid] = (0,react_.useState)(true);
    const [showScannerInModal, setshowScannerInModal] = (0,react_.useState)(false);
    const [balance, setBalance] = (0,react_.useState)(0);
    const [withAmount, setWithAmount] = (0,react_.useState)(0);
    const [withAmountError, setWithAmountError] = (0,react_.useState)("");
    const [success, setSuccess] = (0,react_.useState)();
    const [successAlert, setSuccessAlert] = (0,react_.useState)({
        show: false,
        message: ""
    });
    const [errorAlert, setErrorAlert] = (0,react_.useState)({
        show: false,
        message: ""
    });
    const [error, setError] = (0,react_.useState)();
    const [fees, setFees] = (0,react_.useState)(0);
    const [shouldOpenScanDialog, setShouldOpenScanDialog] = (0,react_.useState)(false);
    const [todayWithdrawn, setTodayWithdrawn] = (0,react_.useState)(0);
    const [withLimit, setWithLimit] = (0,react_.useState)(0);
    const [txHash, setTxHash] = (0,react_.useState)();
    const [transactions, setTransactions] = (0,react_.useState)([]);
    const showScanModal = ()=>{
        setshowScannerInModal(true);
        const { Modal } = __webpack_require__(13811);
        const myModal = new Modal("#scanModal");
        myModal.show();
    };
    const fetchBalance = ()=>{
        (0,make_post_request/* MakePostRequest */.JO)({
            user_id: 1,
            coin,
            network
        }, "wallet/getBalance", props.token).then(async (resp)=>{
            let res = resp.data;
            console.log("response rec", res);
            setBalance(res["balance"]);
            setFees(res["fees"]);
            setWithLimit(res["totalLimit"]);
            setTodayWithdrawn(res["todayWithdrawn"]);
        }).catch((error)=>{
            alert(error);
        });
    };
    (0,react_.useEffect)(()=>{
        if (coin !== undefined) {
            const g = withdraw_network_options[coin];
            setNetwork(g[0].value);
            setNetworks(g);
        }
        if (coin !== undefined && network !== undefined && address != undefined && isValid) {
            fetchBalance();
        }
    }, [
        coin
    ]);
    (0,react_.useEffect)(()=>{
        if (coin !== undefined && network !== undefined && address != undefined && isValid) {
            fetchBalance();
        }
    }, [
        network
    ]);
    (0,react_.useEffect)(()=>{
        if (coin !== undefined && network !== undefined && address != undefined && isValid) {
            fetchBalance();
        }
    //  var ws = new WebSocket("wss://socket.blockcypher.com/v1/btc/test3?token=9956d480d3be413dbca12492589a3da5");
    // var count = 0;
    // ws.onmessage = function (event) {
    //   var tx = JSON.parse(event.data);
    //   var total = tx.total / 100000000;
    //   var addrsese = tx.addresses;
    //   console.log('event', {hash:tx.hash, val:total,address: addrsese})
    //   // count++;
    //   // if (count > 10) ws.close();
    // }
    // ws.onopen = function (event) {
    //  // ws.send(JSON.stringify({event: "ping"}))
    //   ws.send(JSON.stringify({event: "confirmed-tx"}));
    // } 
    }, [
        address
    ]);
    const validateAddress = (address1)=>{
        if (coin !== undefined) {
            console.log("validting coin", coin);
            switch(coin){
                case "BTC":
                    if (network == "Bitcoin") return (0,index_cjs/* validate */.Gu)(address1);
                    else return /^(0x)?[0-9a-fA-F]{40}$/.test(address1);
                case "BNB":
                    return /^(bnb1)[0-9a-z]{38}$/.test(address1) || /^(0x)?[0-9a-fA-F]{40}$/.test(address1) || /^(tbnb1)[0-9a-z]{38}$/.test(address1);
                case "BEP20":
                    return /^(0x)?[0-9a-fA-F]{40}$/.test(address1);
                case "BUSD":
                    return /^(0x)?[0-9a-fA-F]{40}$/.test(address1);
                case "ETH":
                    return /^(0x)?[0-9a-fA-F]{40}$/.test(address1);
                case "ERC20":
                    return /^(0x)?[0-9a-fA-F]{40}$/.test(address1);
                case "TRX":
                    return /^(T)[A-HJ-NP-Za-km-z1-9]{33}$/.test(address1);
                case "USDT":
                    return /^(T)[A-HJ-NP-Za-km-z1-9]{33}$/.test(address1) || /^(0x)?[0-9a-fA-F]{40}$/.test(address1);
            }
        }
    };
    const detectNetwork = (val)=>{
        let message1 = "";
        //  alert()
        console.log("detecting network", val);
        if (val.length > 0) {
            if (coin == "BTC") {
                if (!validateAddress(val)) {
                    message1 = "invalid Bitcoin Address entered";
                }
            } else if (coin == "BNB") {
                if (!validateAddress(val)) {
                    message1 = "Invalid BNB Address entered";
                }
            } else if (coin == "BUSD") {
                if (!validateAddress(val)) {
                    message1 = "Invalid BUSD  Address entered";
                }
            } else if (coin == "ETH") {
                if (!validateAddress(val)) {
                    message1 = "Invalid Ethereum Address entered";
                }
            } else if (coin == "TRX") {
                if (!validateAddress(val)) {
                    message1 = "Invalid Tron Address entered";
                }
            } else if (coin == "USDT") {
                if (!validateAddress(val)) {
                    message1 = "Invalid USDT Address entered";
                }
            }
            if (message1.length > 0) {
                setAddress(undefined);
                setMessage(message1);
                setValid(false);
            } else {
                setValid(true);
                setMessage("");
                if (coin !== undefined) {
                    setAddress(val);
                    let g = withdraw_network_options[coin];
                    setNetworks(g);
                    setNetwork(g[0].value);
                }
            }
        }
    };
    const genrateAddress = ()=>{
        return /*#__PURE__*/ jsx_runtime_.jsx(QRGenerator, {
            value: withdraw_adress,
            width: "100",
            height: "100"
        });
    };
    const handleCopy = ()=>{
        navigator.clipboard.writeText(withdraw_adress);
        setCopyText("Copied");
    };
    const handleWithAmountInput = (val)=>{
        let g = parseFloat(val) + parseFloat(fees);
        console.log("andling", g);
        if (g > balance) setWithAmountError("Insufficent balance including network fees");
        else {
            setWithAmountError("");
            setWithAmount(val);
        }
    };
    const loadTransactions = ()=>{
    // setTransactions(TABLE_ROWS as any);
    };
    const setMaxInput = ()=>{
        console.log("max clicked");
    };
    const renderTransactions = (transactions)=>{};
    const addWebhookIdToDB = (hook_id, hash)=>{
        console.log("adding webok  to hoo");
        let data = {
            "hook_id": hook_id,
            "hash": hash,
            "to": address,
            coin,
            network
        };
        (0,make_post_request/* MakePostRequest */.JO)(data, "addWebhookId", props?.token).then(async (resp)=>{
            let res = resp.data;
        }).catch((err)=>{
            console.log("adding hook error", err);
        });
    };
    const createWebhook = (hash)=>{
        console.log("posting to hoo");
        var webhook = {
            "event": "confirmed-tx",
            "address": address,
            "url": "https://c5dc-2409-4063-4e87-55ed-4903-999d-dfa3-49d0.ngrok-free.app/webhook"
        };
        const url = "https://api.blockcypher.com/v1/btc/test3/hooks?token=9956d480d3be413dbca12492589a3da5";
        (0,make_post_request/* MakePostRequestUrl */.v9)(webhook, url, props.token).then(async (resp)=>{
            let res = resp.data;
            console.log("hook", res);
            addWebhookIdToDB(res["id"], hash);
        }).catch((err)=>{
            console.log("hook error", err);
        });
    };
    const submitWithdrawal = (e)=>{
        e.preventDefault();
        setLoading(true);
        (0,make_post_request/* MakePostRequest */.JO)({
            user_id: 1,
            amount: withAmount,
            coin,
            network,
            fees: fees,
            balance,
            to_address: address
        }, "wallet/withdrawal", props.token).then(async (resp)=>{
            let res = resp.data;
            console.log("wtih scc", res);
            setLoading(false);
            if (res["hash"] !== undefined) {
                if (coin == "BTC" && network == "Bitcoin") {
                    createWebhook(res["hash"]);
                }
            //   setTxHash(res['hash']);
            }
            res["success"] ? setSuccessAlert({
                show: true,
                message: res["message"]
            }) : setErrorAlert({
                show: true,
                message: res["message"]
            });
        }).catch((err)=>{
            console.log("here i", err);
            setLoading(false);
            setError("Some error ocurred");
        });
    };
    const checkTransactionStatus = (coin, network)=>{
        /*https://docs.blocknative.com/mempool-tools/transaction-simulation/pre-flight-simulation#how-to-websocket-endpoint*/ if (coin == "BTC" && network == "Bitcoin") {
            if (txHash === undefined) setErrorAlert({
                show: true,
                message: "No Hash Found"
            });
            else {
                let url = "https://api.blockcypher.com/v1/btc/test3";
                (0,make_post_request/* MakeGetRequestNoQuery */.H1)(url + "/txs/" + txHash, props.token).then(async (resp)=>{
                    console.log("status", await resp.status);
                    let res = resp.data;
                    if (res["block_hash"] === undefined || res["block_height"] < 0) {
                        setErrorAlert({
                            show: true,
                            message: "Transaction is not confirmed"
                        });
                    } else {
                        setSuccessAlert({
                            show: true,
                            message: "Transaction is  confirmed"
                        });
                    }
                }).catch((err)=>{
                    setErrorAlert({
                        show: true,
                        message: "Transaction is not confirmed"
                    });
                    console.log("has erro", err);
                });
            }
        } else if (coin == "BNB" && network == "BEP2") {
            if (txHash === undefined) setErrorAlert({
                show: true,
                message: "No Hash Found"
            });
            else {
                const testnetapiurl = "https://testnet-dex-asiapacific.binance.org";
                const mainnetapiurl = "https://dex-asiapacific.binance.org";
                const apiurl = testnetapiurl;
                let url = `${apiurl}/api/v1/tx/${txHash}`;
                (0,make_post_request/* MakeGetRequestNoQuery */.H1)(url, props.token).then(async (resp)=>{
                    console.log("status", await resp.status);
                    let res = resp.data;
                    console.log("ssf", res);
                    if (res["height"] === undefined || res["height"] < 0) {
                        setErrorAlert({
                            show: true,
                            message: "Transaction is not confirmed"
                        });
                    } else {
                        setSuccessAlert({
                            show: true,
                            message: "Transaction is  confirmed"
                        });
                    }
                }).catch((err)=>{
                    setErrorAlert({
                        show: true,
                        message: "Transaction is not confirmed"
                    });
                    console.log("has erro", err);
                });
            }
        }
    };
    const handleNetworkChange = (e)=>{
        setNetwork(e.currentTarget.value);
    };
    const handleScan = (v)=>{
        console.log("scan", v);
        if (shouldOpenScanDialog) {
            setAddress(v);
        }
        setShouldOpenScanDialog(false);
    // setNetwork(v)
    };
    const handleScanDialogOpen = (v)=>{
        setShouldOpenScanDialog(!shouldOpenScanDialog);
    // setNetwork(v)
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "card-body",
        children: [
            successAlert.show && /*#__PURE__*/ jsx_runtime_.jsx(success_alert/* default */.Z, {
                message: successAlert.message
            }),
            errorAlert.show && /*#__PURE__*/ jsx_runtime_.jsx(error_alert/* default */.Z, {
                message: errorAlert.message
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                children: [
                    message.length > 0 && !isValid ? /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-danger",
                        children: message
                    }) : /*#__PURE__*/ jsx_runtime_.jsx("span", {}),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row g-3 mb-3",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-sm-12",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        className: "form-label",
                                        children: "Select coin"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                                        value: coin,
                                        className: "form-control form-select",
                                        onChange: (e)=>setCoin(e.currentTarget.value),
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                value: "",
                                                children: "Select Coin"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                value: "BTC",
                                                children: "BTC"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                value: "BNB",
                                                children: "BNB"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                value: "USDT",
                                                children: "USDT"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                value: "ETH",
                                                children: "ETH"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                value: "DRNH",
                                                children: "DRNH"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-sm-12",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        className: "form-label",
                                        children: "Withdraw Address"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "row",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "col-md-8",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                    type: "text",
                                                    className: "form-control",
                                                    value: address,
                                                    onChange: (e)=>detectNetwork(e.target.value)
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "col-md-4",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    onClick: (e)=>showScanModal(),
                                                    className: "icofont-qr-code"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-sm-12",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        className: "form-label",
                                        children: "Select Withdraw Network"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                        className: "form-select",
                                        "aria-label": "Default select example",
                                        onChange: (e)=>handleNetworkChange(e),
                                        children: networks.length > 0 ? networks.map((val, i)=>{
                                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("option", {
                                                value: val["value"],
                                                children: [
                                                    " ",
                                                    val["label"],
                                                    "  "
                                                ]
                                            }, i);
                                        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("option", {
                                            value: "",
                                            className: "bg-transparent hover:bg-transparent",
                                            children: [
                                                "Select Network",
                                                " "
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-sm-12",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        className: "form-label",
                                        children: "Amount"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        className: "form-control",
                                        value: withAmount,
                                        onChange: (e)=>handleWithAmountInput(e.target.value)
                                    }),
                                    withAmountError.length > 0 ? /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-danger",
                                        children: withAmountError
                                    }) : null
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-sm-12",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        className: "form-label",
                                        children: "Receive Amount"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    coin != undefined && network != undefined && address != undefined && withAmount > 0 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        children: [
                                            parseFloat(withAmount) - parseFloat(fees),
                                            " ",
                                            coin
                                        ]
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: " Not Available"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {})
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-sm-12",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "d-flex justify-content-between flex-wrap",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "truncated",
                                                    children: [
                                                        coin,
                                                        " spot balance"
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "text-muted truncated",
                                                    children: coin !== undefined && network !== undefined ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            children: [
                                                                balance,
                                                                " ",
                                                                coin
                                                            ]
                                                        })
                                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("span", {})
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "truncated",
                                                    children: "Minimum withdrawal"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "text-muted  truncated",
                                                    children: " 0.0000086 BTC "
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-sm-12",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "d-flex justify-content-between flex-wrap",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "truncated",
                                                    children: "Network fee"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "text-muted truncated",
                                                    children: [
                                                        " ",
                                                        fees ? fees : "Not Available",
                                                        " ",
                                                        coin
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "truncated",
                                                    children: "24h remaining limit"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "text-muted  truncated",
                                                    children: [
                                                        " ",
                                                        todayWithdrawn,
                                                        " ",
                                                        coin,
                                                        "/",
                                                        withLimit,
                                                        " ",
                                                        coin,
                                                        " "
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "mb-3",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                    disabled: loading,
                                    onClick: (e)=>submitWithdrawal(e),
                                    type: "submit",
                                    className: "btn flex-fill btn-light-primary py-2 fs-5 text-uppercase px-5",
                                    children: [
                                        "Submit ",
                                        loading && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "spinner-border spinner-border-sm"
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal fade rounded-0",
                id: "scanModal",
                tabIndex: -1,
                "aria-hidden": "true",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "modal-dialog rounded-0",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "modal-content rounded-0",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "modal-header",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: "modal-title",
                                        children: "Scan Modal"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        type: "button",
                                        className: "btn-close",
                                        "data-bs-dismiss": "modal",
                                        "aria-label": "Close"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "modal-body",
                                children: showScannerInModal ? /*#__PURE__*/ jsx_runtime_.jsx(QRScanner, {
                                    onResult1: (data)=>handleScan(data)
                                }) : null
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "modal-footer",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        type: "button",
                                        className: "btn btn-secondary",
                                        "data-bs-dismiss": "modal",
                                        children: "Close"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        type: "button",
                                        className: "btn btn-primary",
                                        children: "Verify"
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/next-auth/react/index.js
var react = __webpack_require__(63370);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
;// CONCATENATED MODULE: ./app/(home)/backend/wallet/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





const page_network_options = {
    BTC: [
        {
            value: "BEP20",
            label: "Binance Smart Chain BEP20"
        },
        {
            value: "Bitcoin",
            label: "Bitcoin"
        }
    ],
    BNB: [
        {
            value: "BEP20",
            label: "Binance Smart Chain BEP20"
        },
        {
            value: "",
            label: ""
        }
    ],
    ETH: [
        {
            value: "Ethereum",
            label: "Ethereum"
        },
        {
            value: "",
            label: ""
        }
    ],
    USDT: [
        {
            value: "BEP20",
            label: "BEP20"
        },
        {
            value: "",
            label: ""
        }
    ],
    DRNH: [
        {
            value: "BEP20",
            label: "Binance Smart Chain"
        },
        {
            value: "",
            label: ""
        }
    ]
};
let authToken;
function Wallet() {
    const { status, data: session } = (0,react.useSession)();
    (0,react_.useEffect)(()=>{
        if (status == "authenticated") {
            authToken = session?.user?.accessToken;
        } else if (status == "unauthenticated") {
            return (0,navigation.redirect)("auth/login");
        }
    }, [
        status
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "body d-flex py-3",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container-xxl",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row align-items-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "border-0 mb-4",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "card-header py-3 no-bg bg-transparent d-flex align-items-center px-0 justify-content-between border-bottom flex-wrap",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: "fw-bold mb-0",
                                children: " Wallet1"
                            })
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container-xxl",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row g-3 mb-3 row-deck",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-xl-6 col-xxl-6",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "card",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "card-header py-3 d-flex justify-content-between bg-transparent align-items-center",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                    className: "mb-0 fw-bold",
                                                    children: "Withdraw Crypto"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(Withdraw, {
                                                network_options: page_network_options,
                                                token: authToken
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-xl-6 col-xxl-6",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "card",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "card-header py-3 d-flex justify-content-between bg-transparent border-bottom align-items-center flex-wrap",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                    className: "mb-0 fw-bold",
                                                    children: "Deposit"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(Deposit, {
                                                network_options: page_network_options,
                                                token: authToken
                                            })
                                        ]
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "row",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-12",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "card no-bg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "card-header py-3 d-flex justify-content-between",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                className: "mb-0 fw-bold",
                                                children: "Transaction History"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "card-body",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                                                id: "ordertabthree",
                                                className: "priceTable table table-hover custom-table table-bordered align-middle mb-0",
                                                style: {
                                                    width: "100%"
                                                },
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                                    children: "Date"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                                    children: "Type"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                                    children: "Asset"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                                    children: "Amount"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                                    children: "Status"
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tbody", {
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "2021-09-22 22:04"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "Withdraw"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "USDT"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "481.90172092"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            className: "color-price-up",
                                                                            children: "Completed"
                                                                        })
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "2021-09-01 23:50"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "Deposit"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "USDT"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "323.50000000"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            className: "color-price-up",
                                                                            children: "Completed"
                                                                        })
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "2021-08-21 14:07"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "Withdraw"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "USDT"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "99.00000000"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            className: "color-price-up",
                                                                            children: "Completed"
                                                                        })
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "2021-08-18 13:07"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "Deposit"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "USDT"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "459.00000000"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            className: "color-price-down",
                                                                            children: "Cancle"
                                                                        })
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "2021-07-28 22:06"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "Deposit"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "BNB"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "459.00000000"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            className: "color-price-up",
                                                                            children: "Completed"
                                                                        })
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "2021-07-27 22:06"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "Deposit"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "BTC"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "59.00000000"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            className: "color-price-up",
                                                                            children: "Completed"
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 54001:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`E:\exchange\boottest\app\(home)\backend\wallet\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [763,489,609,977,869,813,967,332,503,232,364,894,528,916,15,602,436], () => (__webpack_exec__(12787)));
module.exports = __webpack_exports__;

})();