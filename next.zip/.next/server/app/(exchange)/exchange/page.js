(() => {
var exports = {};
exports.id = 965;
exports.ids = [965];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 86819:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 78618:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(exchange)',
        {
        children: [
        'exchange',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 40654)), "E:\\exchange\\boottest\\app\\(exchange)\\exchange\\page.tsx"],
          
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 38154)), "E:\\exchange\\boottest\\app\\(exchange)\\exchange\\layout.tsx"],
          
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["E:\\exchange\\boottest\\app\\(exchange)\\exchange\\page.tsx"];
    
    const originalPathname = "/(exchange)/exchange/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 3700:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 66940))

/***/ }),

/***/ 66940:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Exchange)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _app_components_order_book__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62940);
/* harmony import */ var _app_components_trade__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(50910);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(63370);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _app_util_make_post_request__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5916);
/* harmony import */ var _app_components_ticker__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(58705);
/* harmony import */ var _app_util_helpers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(59495);
/* harmony import */ var _app_components_success_alert__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(10445);
/* harmony import */ var _app_components_error_alert__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(98316);
/* __next_internal_client_entry_do_not_use__ default auto */ 



const crypto = __webpack_require__(6113);







let ws;
let authToken;
function Exchange() {
    const { status, data: session } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_5__.useSession)();
    const binance_url = "https://testnet.binance.vision/api/v3";
    const binance_stream = "wss://testnet.binance.vision/ws";
    const [wsInstance, setWsInstance] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(null);
    const [side, setSide] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(null);
    const [mainCoinBalance, setMainCoinBalance] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const [marketPrice, setMarketPrice] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [type, setType] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("LIMIT");
    const [ticker, setTicker] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [usdtInput, setUsdtInput] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const [symbolPriceRules, setSymbolPriceRules] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [htmlPriceRulesBuy, setHtmlPriceRulesBuy] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [htmlPriceRulesSell, setHtmlPriceRulesSell] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [btcInput, setBtcInput] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(1);
    const [usdtInputSell, setUsdtInputSell] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const [btcInputSell, setBtcInputSell] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(1);
    const [priceInputBuy, setPriceInputBuy] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [priceInputSell, setPriceInputSell] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [usdtInputSellMarket, setUsdtInputSellMarket] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const [btcInputSellMarket, setBtcInputSellMarket] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(1);
    const [usdtInputBuyMarket, setUsdtInputBuyMarket] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const [btcInputBuyMarket, setBtcInputBuyMarket] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(1);
    const [loadingBuy, setLoadingBuy] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [loadingSell, setLoadingSell] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [loadingBuyMarket, setLoadingBuyMarket] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [loadingSellMarket, setLoadingSellMarket] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [btnDisabled, setBtnDisabled] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [usdtBalance, setUsdtBalance] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const [errorBuySide, setErrorBuySide] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [errorSellSide, setErrorSellSide] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [errorBuySideMarket, setErrorBuySideMarket] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [errorSellSideMarket, setErrorSellSideMarket] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [orderList, setOrderList] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const [errorAlert, setErrorAlert] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        show: false,
        message: ""
    });
    const [successAlert, setSuccessAlert] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        show: false,
        message: ""
    });
    const symbol = "BTCUSDT";
    let network = "BEP20";
    const main_currency = symbol.substr(0, symbol.indexOf("USDT"));
    if (main_currency == "BTC") network = "Bitcoin";
    else if (main_currency == "ETH") network = "Ethereum";
    else if (main_currency == "DRNH" || main_currency == "BNB") network = "BEP20";
    const time = Date.now() + 10000;
    // var timestamp = moment().unix();
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (marketPrice !== undefined) {
            setUsdtInput(priceInputBuy * btcInput);
            setUsdtInputSell(priceInputSell * btcInputSell);
        }
    }, [
        marketPrice
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (status == "authenticated") {
            authToken = session?.user?.accessToken;
            console.log("token", authToken);
            (0,_app_util_make_post_request__WEBPACK_IMPORTED_MODULE_9__/* .MakeGetRequestNoQuery */ .H1)(`binance/allUserOrders`, authToken).then((resp)=>{
                let x = resp.data.data;
                console.log("orders list resp", JSON.parse(x));
                setOrderList(JSON.parse(x));
            }).catch((err)=>{
                console.log("error in feetchign orders");
            });
            (0,_app_util_make_post_request__WEBPACK_IMPORTED_MODULE_9__/* .MakePostRequest */ .JO)({
                network,
                coin: main_currency
            }, "binance/fetchBalanceFromTable", authToken).then((resp)=>{
                let wallet = resp.data.data;
                setMainCoinBalance(wallet["main_balance"]);
                setUsdtBalance(wallet["usdt_balance"]);
            }).catch((err)=>{
                console.log("balacne error", err);
                setMainCoinBalance(0);
                setUsdtBalance(0);
            });
        } else if (status == "unauthenticated") {
            return (0,next_navigation__WEBPACK_IMPORTED_MODULE_4__.redirect)("auth/login");
        }
    }, [
        status,
        main_currency
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        const { Popover } = __webpack_require__(13811);
        if (type == "LIMIT") {
            if (symbolPriceRules !== undefined && marketPrice !== undefined) {
                let ruleForBid = (0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .priceRule */ .U9)(symbolPriceRules, type, marketPrice, "bid");
                console.log("bid rule", ruleForBid);
                let htmlForPrice = `<h6>Bid Price Rule</h6><span class='text-muted fw-lighter'>Max Allowed Price-<b>${Math.min(...ruleForBid.max_price_ar)}</b>, 
                Min Allowed Price-<b>${Math.max(...ruleForBid.min_price_ar)}</b></span><br>${ruleForBid["str_price"]}`;
                let htmlForQty = `<h6>Quantity Rule</h6><span class='fw-lighter'>Max Allowed Qty-<b>${Math.min(ruleForBid.max_qty_ar)}</b>, 
                          Min Allowed Qty-<b>${Math.max(ruleForBid.min_qty_ar)}</b></span><br>${ruleForBid["str_qty"]}`;
                let htmlForUsdt = `<h6>USDT Amount Rule</h6>${ruleForBid["str"]}`;
                htmlForQty = type == "MARKET" ? `<h6>Quantity Rule</h6>${ruleForBid["str_market_qty"]}` : `${htmlForQty}`;
                let content = type == "LIMIT" ? htmlForPrice + htmlForQty + htmlForUsdt : htmlForQty + htmlForUsdt;
                const popoverBuy = new Popover(document.querySelector("#popBuy"), {
                    html: true,
                    content: content
                });
                let ruleForAsk = (0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .priceRule */ .U9)(symbolPriceRules, type, marketPrice, "ask");
                htmlForPrice = `<h6>Ask Price Rule</h6><span class='fw-lighter'>Max Allowed Price-<b>${Math.min(...ruleForAsk.max_price_ar)}</b>,
                        Min Allowed Price-<b>${Math.max(...ruleForAsk.min_price_ar)}</b></span><br>${ruleForAsk["str_price"]}`;
                htmlForQty = `<h6>Quantity Rule</h6><span class='fw-lighter'>Max Allowed Qty-<b>${Math.min(...ruleForAsk.max_qty_ar)}</b>,
        Min Allowed Qty-<b>${Math.max(...ruleForAsk.min_qty_ar)}</b></span><br>${ruleForAsk["str_qty"]}`;
                htmlForUsdt = `<h6>USDT Amount Rule</h6>${ruleForAsk["str"]}`;
                htmlForQty = type == "MARKET" ? `<h6>Quantity Rule</h6>${ruleForAsk["str_market_qty"]}` : `${htmlForQty}`;
                content = type == "LIMIT" ? htmlForPrice + htmlForQty + htmlForUsdt : htmlForQty + htmlForUsdt;
                const popoverSell = new Popover(document.querySelector("#popSell"), {
                    html: true,
                    content: content
                });
            //  setHtmlPriceRulesBuy(htmlForBuy)
            //  setHtmlPriceRulesSell(htmlForSell)
            }
        } else {
            if (symbolPriceRules !== undefined && marketPrice !== undefined) {
                let ruleForBid = (0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .priceRule */ .U9)(symbolPriceRules, type, marketPrice, "bid");
                let htmlForQty = `<h6>Quantity Rule</h6><span class='fw-lighter'>Max Allowed Qty-<b>${Math.min(ruleForBid.max_qty_ar)}</b>, 
                          Min Allowed Qty-<b>${Math.max(ruleForBid.min_qty_ar)}</b></span><br>${ruleForBid["str_qty"]}`;
                let htmlForUsdt = `<h6>USDT Amount Rule</h6>${ruleForBid["str"]}`;
                htmlForQty = type == "MARKET" ? `<h6>Quantity Rule</h6>${ruleForBid["str_market_qty"]}` : `${htmlForQty}`;
                let content = htmlForQty + htmlForUsdt;
                const popoverBuy = new Popover(document.querySelector("#popBuy1"), {
                    html: true,
                    content: content
                });
                let ruleForAsk = (0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .priceRule */ .U9)(symbolPriceRules, type, marketPrice, "ask");
                htmlForQty = `<h6>Quantity Rule</h6><span class='fw-lighter'>Max Allowed Qty-<b>${Math.min(...ruleForAsk.max_qty_ar)}</b>,
        Min Allowed Qty-<b>${Math.max(...ruleForAsk.min_qty_ar)}</b></span><br>${ruleForAsk["str_qty"]}`;
                htmlForUsdt = `<h6>USDT Amount Rule</h6>${ruleForAsk["str"]}`;
                htmlForQty = type == "MARKET" ? `<h6>Quantity Rule</h6>${ruleForAsk["str_market_qty"]}` : `${htmlForQty}`;
                content = htmlForQty + htmlForUsdt;
                const popoverSell = new Popover(document.querySelector("#popSell1"), {
                    html: true,
                    content: content
                });
            }
        }
    }, [
        type,
        symbolPriceRules,
        marketPrice
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        (0,_app_util_make_post_request__WEBPACK_IMPORTED_MODULE_9__/* .MakeGetRequestRemoteQuery */ .lA)({
            symbol
        }, `${binance_url}/exchangeInfo?symbol=${main_currency}USDT`).then((resp)=>{
            let x = resp.data;
            let symbolPriceRulesp = x["symbols"][0];
            console.log("filer resp", symbolPriceRulesp);
            setSymbolPriceRules(symbolPriceRulesp);
        }).catch((err)=>{
            console.log("error in feetchign exhnge info");
        });
        (0,_app_util_make_post_request__WEBPACK_IMPORTED_MODULE_9__/* .MakeGetRequestRemoteQuery */ .lA)({
            network,
            coin: main_currency
        }, `${binance_url}/ticker/24hr?symbol=${main_currency}USDT`).then((resp)=>{
            let x = resp.data;
            console.log("24h re", resp.data);
            let item = {
                priceChange: x.priceChange,
                priceChangePercent: x.priceChangePercent,
                lastPrice: x.lastPrice,
                highPrice: x.highPrice,
                lowPrice: x.lowPrice,
                volume: x.volume,
                quoteVolume: x.quoteVolume
            };
            setTicker(item);
            setMarketPrice((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(resp.data.lastPrice, 5));
            setPriceInputBuy((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(resp.data.lastPrice, 5));
            setPriceInputSell((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(resp.data.lastPrice, 5));
        /*    ws = new WebSocket(binance_stream);
            ws.onopen = function () {
              ws.send(JSON.stringify(
                {
                  "method": "SUBSCRIBE",
                  "params": [
                    `bnbusdt@ticker`,
    
    
                  ],
                  "id": 12
                }
              ))
              console.log("Connection opened...");
            };
    
            ws.onmessage = function (event: any) {
              const r = JSON.parse(event.data);
              console.log('socket reultr', r['result'])
              if (r['result'] === undefined) {
                console.log('here goes ', r)
                let item = {
                  priceChange: r.p,
                  priceChangePercent: r.P,
                  lastPrice: r.c,
                  highPrice: r.h,
                  lowPrice: r.l,
                  volume: r.v,
                  quoteVolume: r.q,
                }
                setTicker(item)
    
                // updateData(data => [...data, res1]); console.log('now', data)
              }
            };
    
            ws.onclose = function () {
              console.log("Connection closed...");
            };
    */ }).catch((err)=>{
            console.log("balacne error", err);
            setMainCoinBalance(0);
            setUsdtBalance(0);
        });
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setErrorBuySide(undefined);
        verifyBalanceAndQty(usdtInput, "USDT");
        if (symbolPriceRules !== undefined && marketPrice !== undefined && symbolPriceRules !== undefined) {
            const filter_error = (0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .filterOrder */ .Xs)(symbolPriceRules, priceInputBuy, btcInput, "bid", marketPrice, type, usdtInput);
            if (filter_error.length > 2) {
                setErrorBuySide(filter_error);
            }
        // else  setErrorBuySide(undefined)
        }
    }, [
        usdtInput
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setErrorBuySide(undefined);
        verifyBalanceAndQty(usdtInput, "USDT");
        if (symbolPriceRules !== undefined && marketPrice !== undefined && symbolPriceRules !== undefined) {
            const filter_error = (0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .filterOrder */ .Xs)(symbolPriceRules, priceInputBuy, btcInput, "bid", marketPrice, type, usdtInput);
            if (filter_error.length > 2) {
                setErrorBuySide(filter_error);
            }
        // else  setErrorBuySide(undefined)
        }
    }, [
        btcInput
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setErrorSellSide(undefined);
        verifyBalanceAndQty(btcInputSell, "BTC");
        if (symbolPriceRules !== undefined && marketPrice !== undefined && symbolPriceRules !== undefined) {
            const filter_error = (0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .filterOrder */ .Xs)(symbolPriceRules, priceInputSell, btcInputSell, "ask", marketPrice, type, usdtInputSell);
            if (filter_error.length > 2) {
                setErrorSellSide(filter_error);
            }
        // else  setErrorSellSide(undefined)
        }
    }, [
        usdtInputSell
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setErrorSellSide(undefined);
        verifyBalanceAndQty(btcInputSell, "BTC");
        if (symbolPriceRules !== undefined && marketPrice !== undefined && symbolPriceRules !== undefined) {
            const filter_error = (0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .filterOrder */ .Xs)(symbolPriceRules, priceInputSell, btcInputSell, "ask", marketPrice, type, usdtInputSell);
            if (filter_error.length > 2) {
                setErrorSellSide(filter_error);
            }
        // else  setErrorSellSide(undefined)
        }
    }, [
        btcInputSell
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setErrorBuySideMarket(undefined);
        verifyBalanceAndQty(usdtInputBuyMarket, "USDT");
        if (symbolPriceRules !== undefined && marketPrice !== undefined && symbolPriceRules !== undefined) {
            const filter_error = (0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .filterOrder */ .Xs)(symbolPriceRules, priceInputSell, btcInputBuyMarket, "ask", marketPrice, type, usdtInputBuyMarket);
            if (filter_error.length > 2) {
                setErrorBuySideMarket(filter_error);
            }
        }
    }, [
        usdtInputBuyMarket
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setErrorSellSideMarket(undefined);
        verifyBalanceAndQty(btcInputSellMarket, "BTC");
        if (symbolPriceRules !== undefined && marketPrice !== undefined && symbolPriceRules !== undefined) {
            const filter_error = (0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .filterOrder */ .Xs)(symbolPriceRules, priceInputSell, btcInputSellMarket, "ask", marketPrice, type, usdtInputSellMarket);
            if (filter_error.length > 2) {
                setErrorSellSideMarket(filter_error);
            }
        }
    }, [
        usdtInputSellMarket
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setErrorSellSideMarket(undefined);
        verifyBalanceAndQty(btcInputSellMarket, "BTC");
        if (symbolPriceRules !== undefined && marketPrice !== undefined && symbolPriceRules !== undefined) {
            const filter_error = (0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .filterOrder */ .Xs)(symbolPriceRules, priceInputSell, btcInputSellMarket, "ask", marketPrice, "MARKET", usdtInputSellMarket);
            if (filter_error.length > 2) {
                setErrorSellSideMarket(filter_error);
            }
        }
    }, [
        btcInputSellMarket
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setErrorBuySideMarket(undefined);
        verifyBalanceAndQty(usdtInputBuyMarket, "USDT");
        if (symbolPriceRules !== undefined && marketPrice !== undefined && symbolPriceRules !== undefined) {
            const filter_error = (0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .filterOrder */ .Xs)(symbolPriceRules, priceInputSell, btcInputBuyMarket, "bid", marketPrice, "MARKET", usdtInputBuyMarket);
            if (filter_error.length > 2) {
                setErrorBuySideMarket(filter_error);
            }
        }
    }, [
        btcInputBuyMarket
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setErrorBuySide(undefined);
        verifyBalanceAndQty(usdtInput, "USDT");
        if (symbolPriceRules !== undefined && marketPrice !== undefined && symbolPriceRules !== undefined) {
            const filter_error = (0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .filterOrder */ .Xs)(symbolPriceRules, priceInputBuy, btcInput, "bid", marketPrice, type, usdtInput);
            if (filter_error.length > 2) {
                setErrorBuySide(filter_error);
            }
        // else  setErrorBuySide(undefined)
        }
    }, [
        priceInputBuy
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setErrorSellSide(undefined);
        verifyBalanceAndQty(btcInputSell, "BTC");
        if (symbolPriceRules !== undefined && marketPrice !== undefined && symbolPriceRules !== undefined) {
            const filter_error = (0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .filterOrder */ .Xs)(symbolPriceRules, priceInputSell, btcInputSell, "ask", marketPrice, type, usdtInputSell);
            if (filter_error.length > 2) {
                setErrorSellSide(filter_error);
            }
        // else  setErrorSellSide(undefined)
        }
    }, [
        priceInputSell
    ]);
    const handlePriceInputBuyChange = (e)=>{
        setPriceInputBuy(e.currentTarget.value);
        if (btcInput !== undefined) setUsdtInput((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(e.currentTarget.value * btcInput, 5));
    };
    const handleBtcInputChange = (e)=>{
        setBtcInput(e.currentTarget.value);
        if (marketPrice !== undefined) setUsdtInput((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(e.currentTarget.value * priceInputBuy, 5));
    };
    const handlePriceInputSellChange = (e)=>{
        setPriceInputSell(e.currentTarget.value);
        if (btcInput !== undefined) setUsdtInputSell((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(e.currentTarget.value * btcInputSell, 5));
    };
    const handleBtcInputSellChange = (e)=>{
        setBtcInputSell(e.currentTarget.value);
        if (priceInputSell !== undefined) setUsdtInputSell((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(e.currentTarget.value * priceInputSell, 5));
    };
    const handleUsdtInputBuyChange = (e)=>{
        setUsdtInput(e.currentTarget.value);
        if (priceInputSell !== undefined && priceInputBuy > 0) setBtcInput((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(e.currentTarget.value / priceInputBuy, 5));
    };
    const handleUsdtInputSellChange = (e)=>{
        setUsdtInputSell(e.currentTarget.value);
        if (priceInputSell !== undefined && priceInputBuy > 0) setBtcInputSell((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(e.currentTarget.value / priceInputSell, 5));
    };
    const handleUsdtInputBuyMarketChange = (e)=>{
        setUsdtInputBuyMarket(e.currentTarget.value);
        if (marketPrice !== undefined && marketPrice > 0) setBtcInputBuyMarket((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(e.currentTarget.value / marketPrice, 5));
    };
    const handleUsdtInputSellMarketChange = (e)=>{
        setUsdtInputSellMarket(e.currentTarget.value);
        if (marketPrice !== undefined && marketPrice > 0) setBtcInputSellMarket((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(e.currentTarget.value / marketPrice, 5));
    };
    const handleBtcInputBuyMarketChange = (e)=>{
        setBtcInputBuyMarket(e.currentTarget.value);
        if (marketPrice !== undefined) setUsdtInputBuyMarket((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(e.currentTarget.value * marketPrice, 5));
    };
    const handleBtcInputSellMarketChange = (e)=>{
        setBtcInputSellMarket(e.currentTarget.value);
        if (marketPrice !== undefined) setUsdtInputSellMarket((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(e.currentTarget.value * marketPrice, 5));
    };
    const handlePercentChange = (side1, percent)=>{
        if (type == "LIMIT") {
            if (side1 == "BUY") {
                let f = Number(usdtBalance) * percent / 100;
                setUsdtInput((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(f, 5));
                setBtcInput((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(f / priceInputBuy, 5));
            } else {
                let f = Number(mainCoinBalance) * percent / 100;
                setBtcInputSell((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(f, 5));
                setUsdtInputSell((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(f * priceInputSell, 5));
            }
        } else {
            if (side1 == "BUY") {
                let f = Number(usdtBalance) * percent / 100;
                setUsdtInputBuyMarket((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(f, 5));
                setBtcInputBuyMarket((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(f / marketPrice, 5));
            } else {
                let f = Number(mainCoinBalance) * percent / 100;
                setBtcInputSellMarket((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(f, 5));
                setUsdtInputSellMarket((0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(f * marketPrice, 5));
            }
        }
    };
    const verifyBalanceAndQty = (inputAmount, coin)=>{
        if (type == "LIMIT") {
            if (coin == main_currency) {
                if (parseFloat(inputAmount) > Number(mainCoinBalance)) {
                    // setBtcInputSell(0.0)
                    setErrorSellSide("Insufficient Balance");
                } else {
                    setErrorSellSide(undefined);
                }
            } else {
                if (parseFloat(inputAmount) > Number(usdtBalance)) {
                    // setBtcInputSell(0.0)
                    setErrorBuySide("Insufficient Balance");
                } else {
                    setErrorBuySide(undefined);
                }
            }
        } else {
            if (coin == main_currency) {
                if (parseFloat(inputAmount) > Number(mainCoinBalance)) {
                    // setBtcInputSell(0.0)
                    setErrorSellSideMarket("Insufficient Balance");
                } else {
                    setErrorSellSideMarket(undefined);
                }
            } else {
                if (parseFloat(inputAmount) > Number(usdtBalance)) {
                    console.log("hrerr");
                    setErrorBuySideMarket("Insufficient Balance");
                }
            }
        }
    };
    const handleSubmit = async (e, side1)=>{
        e.preventDefault();
        if (type == "LIMIT") {
            if (side1 == "BUY") {
                if (usdtInput <= 0 || btcInput <= 0) return;
            } else {
                if (btcInputSell <= 0 || usdtInputSell <= 0) return;
            }
            if (authToken === undefined) alert("Please login");
            try {
                //alert(btcInput)
                let quantity = side1 == "BUY" ? btcInput : btcInputSell;
                if (quantity < 1) quantity = String(Number(quantity)).padStart(0);
                let price = side1 == "BUY" ? priceInputBuy : priceInputSell;
                if (price < 1) price = String(Number(price)).padStart(0);
                side1 == "BUY" ? setLoadingBuy(true) : setLoadingSell(true);
                const response = await (0,_app_util_make_post_request__WEBPACK_IMPORTED_MODULE_9__/* .MakePostRequest */ .JO)({
                    side: side1,
                    type,
                    symbol,
                    price,
                    quantity,
                    main_currency,
                    secondary_currency: "USDT"
                }, "binance/placeOrder", authToken);
                console.log("place orde repose", response.data.data);
                setOrderList(JSON.parse(response.data.data));
                if (response.data.success) setSuccessAlert({
                    show: true,
                    message: response.data.message
                });
                else setErrorAlert({
                    show: true,
                    message: response.data.message
                });
                side1 == "BUY" ? setLoadingBuy(false) : setLoadingSell(false);
            } catch (err) {
                side1 == "BUY" ? setLoadingBuy(false) : setLoadingSell(false);
                if (err.isAxiosError) {
                    console.log(err.response.data);
                    setErrorAlert({
                        show: true,
                        message: err.response.data.message
                    });
                } else setErrorAlert({
                    show: true,
                    message: err
                });
            }
        } else {
            if (side1 == "BUY") {
                if (usdtInputBuyMarket <= 0 || btcInputBuyMarket <= 0) return;
            } else {
                if (btcInputSellMarket <= 0 || usdtInputSellMarket <= 0) return;
            }
            if (authToken === undefined) alert("Please login");
            try {
                //alert(btcInput)
                let quantity = side1 == "BUY" ? btcInputBuyMarket : btcInputSellMarket;
                if (quantity < 1) quantity = String(Number(quantity)).padStart(0);
                side1 == "BUY" ? setLoadingBuyMarket(true) : setLoadingSellMarket(true);
                const response = await (0,_app_util_make_post_request__WEBPACK_IMPORTED_MODULE_9__/* .MakePostRequest */ .JO)({
                    side: side1,
                    type,
                    symbol,
                    price: null,
                    quantity,
                    main_currency,
                    secondary_currency: "USDT"
                }, "binance/placeOrder", authToken);
                console.log("place orde market repose", response.data);
                if (response.data.success) setSuccessAlert({
                    show: true,
                    message: response.data.message
                });
                else setErrorAlert({
                    show: true,
                    message: response.data.message
                });
                side1 == "BUY" ? setLoadingBuyMarket(false) : setLoadingSellMarket(false);
            } catch (err) {
                side1 == "BUY" ? setLoadingBuyMarket(false) : setLoadingSellMarket(false);
                if (err.isAxiosError) {
                    console.log(err.response.data);
                    setErrorAlert({
                        show: true,
                        message: err.response.data.message
                    });
                } else setErrorAlert({
                    show: true,
                    message: err
                });
            }
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "body d-flex py-3 pt-4",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container-xxl",
            children: [
                successAlert.show && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_app_components_success_alert__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    message: successAlert.message
                }),
                errorAlert.show && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_app_components_error_alert__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                    message: errorAlert.message
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "card",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "card-body",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-md-2 text-center  pt-3",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h5", {
                                        children: [
                                            main_currency,
                                            "/USDT"
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-md-10 pt-2",
                                    children: ticker !== undefined ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_app_components_ticker__WEBPACK_IMPORTED_MODULE_6__/* .Ticker */ .v, {
                                        ticker: ticker,
                                        mainCurrency: main_currency
                                    }) : ""
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "row  mb-3",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-3",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "card",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "card-header py-3 d-flex justify-content-between bg-transparent border-bottom-0",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                            className: "mb-0 fw-bold ",
                                            children: "Order Book"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_app_components_order_book__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                        coin: main_currency
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "col-md-6",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "card",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "card-body"
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "card mb-3",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "card-header py-3 d-flex justify-content-between bg-transparent border-bottom-0",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                className: "mb-0 fw-bold ",
                                                children: "Place Order"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "card-body",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                    className: "nav nav-tabs tab-body-header rounded d-inline-flex",
                                                    role: "tablist",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            className: "nav-item",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                className: `nav-link pointer ${type == "LIMIT" ? "active" : ""}`,
                                                                onClick: (e)=>setType("LIMIT"),
                                                                role: "tab",
                                                                children: "Limit"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            className: "nav-item",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                className: `nav-link pointer ${type == "MARKET" ? "active" : ""}`,
                                                                onClick: (e)=>setType("MARKET"),
                                                                role: "tab",
                                                                children: "Market"
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "tab-content",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: `tab-pane fade ${type == "LIMIT" ? "show active" : ""}`,
                                                            id: "Limit",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "row g-3",
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "col-lg-6",
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                className: "d-flex align-items-center justify-content-between my-3",
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                        className: "small text-muted",
                                                                                        children: "Avbl"
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                        className: "",
                                                                                        children: [
                                                                                            (0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(usdtBalance, 5),
                                                                                            " USDT"
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                                                                children: [
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                                                        "data-trigger": "focus",
                                                                                        style: {
                                                                                            borderBottom: "1px dotted blue"
                                                                                        },
                                                                                        role: "button",
                                                                                        type: "button",
                                                                                        className: "mb-1",
                                                                                        id: "popBuy",
                                                                                        "data-bs-toggle": "popover",
                                                                                        title: "Order Rules",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                                                                                children: "\xa0\xa0Price Rules"
                                                                                            }),
                                                                                            " "
                                                                                        ]
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        className: "input-group mb-3",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "input-group-text",
                                                                                                children: "Price"
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                                type: "text",
                                                                                                className: "form-control",
                                                                                                value: priceInputBuy,
                                                                                                onChange: (e)=>handlePriceInputBuyChange(e)
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "input-group-text",
                                                                                                children: "USDT"
                                                                                            })
                                                                                        ]
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        className: "input-group mb-3",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "input-group-text",
                                                                                                children: "Amount"
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                                type: "text",
                                                                                                className: "form-control",
                                                                                                value: btcInput,
                                                                                                onChange: (e)=>handleBtcInputChange(e)
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "input-group-text",
                                                                                                children: main_currency
                                                                                            })
                                                                                        ]
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                        className: "input-group mb-3",
                                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                            className: "mb-2 d-flex justify-content-between align-items-center w-100",
                                                                                            children: [
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-muted pointer",
                                                                                                    onClick: (e)=>handlePercentChange("BUY", 0),
                                                                                                    children: "0%"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-muted px-2 pointer",
                                                                                                    onClick: (e)=>handlePercentChange("BUY", 25),
                                                                                                    children: "25%"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-muted px-1 pointer",
                                                                                                    onClick: (e)=>handlePercentChange("BUY", 50),
                                                                                                    children: "50%"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-muted px-1 pointer",
                                                                                                    onClick: (e)=>handlePercentChange("BUY", 75),
                                                                                                    children: "75%"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-muted pointer",
                                                                                                    onClick: (e)=>handlePercentChange("BUY", 100),
                                                                                                    children: "100%"
                                                                                                })
                                                                                            ]
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        className: "input-group mb-3",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "input-group-text",
                                                                                                children: "Total"
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                                type: "text",
                                                                                                className: "form-control",
                                                                                                value: usdtInput,
                                                                                                onChange: (e)=>handleUsdtInputBuyChange(e)
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "input-group-text",
                                                                                                children: "USDT"
                                                                                            })
                                                                                        ]
                                                                                    }),
                                                                                    errorBuySide !== undefined ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                        className: "text-danger m-2",
                                                                                        children: errorBuySide
                                                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                        children: "\xa0"
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                        disabled: loadingBuy || errorBuySide !== undefined && errorBuySide.length > 0,
                                                                                        type: "button",
                                                                                        onClick: (e)=>handleSubmit(e, "BUY"),
                                                                                        className: "btn flex-fill btn-light-success py-2 fs-5 text-uppercase px-5 w-100",
                                                                                        children: loadingBuy ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                            className: "d-flex align-items-center align-content-center ",
                                                                                            children: [
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "spinner-border spinner-border-md"
                                                                                                }),
                                                                                                "BUY ",
                                                                                                main_currency
                                                                                            ]
                                                                                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                            children: [
                                                                                                " BUY ",
                                                                                                main_currency,
                                                                                                " "
                                                                                            ]
                                                                                        })
                                                                                    })
                                                                                ]
                                                                            })
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "col-lg-6",
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                className: "d-flex align-items-center justify-content-between my-3",
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                        className: "small text-muted",
                                                                                        children: "Avbl"
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                        className: "",
                                                                                        children: [
                                                                                            (0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(mainCoinBalance, 5),
                                                                                            " ",
                                                                                            main_currency
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                                                                children: [
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                                                        "data-trigger": "focus",
                                                                                        style: {
                                                                                            borderBottom: "1px dotted blue"
                                                                                        },
                                                                                        role: "button",
                                                                                        type: "button",
                                                                                        className: "mb-1",
                                                                                        id: "popSell",
                                                                                        "data-bs-toggle": "popover",
                                                                                        title: "order Rules",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                                                                                children: "\xa0\xa0Price Rules"
                                                                                            }),
                                                                                            " "
                                                                                        ]
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        className: "input-group mb-3",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "input-group-text",
                                                                                                children: "Price"
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                                type: "text",
                                                                                                className: "form-control",
                                                                                                value: priceInputSell,
                                                                                                onChange: (e)=>handlePriceInputSellChange(e)
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "input-group-text",
                                                                                                children: "USDT"
                                                                                            })
                                                                                        ]
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        className: "input-group mb-3",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "input-group-text",
                                                                                                children: "Amount"
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                                type: "text",
                                                                                                className: "form-control",
                                                                                                value: btcInputSell,
                                                                                                onChange: (e)=>handleBtcInputSellChange(e)
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "input-group-text",
                                                                                                children: main_currency
                                                                                            })
                                                                                        ]
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                        className: "input-group mb-3",
                                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                            className: "mb-2 d-flex justify-content-between align-items-center w-100",
                                                                                            children: [
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-muted pointer",
                                                                                                    onClick: (e)=>handlePercentChange("SELL", 0),
                                                                                                    children: "0%"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-muted px-2 pointer",
                                                                                                    onClick: (e)=>handlePercentChange("SELL", 25),
                                                                                                    children: "25%"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-muted px-1 pointer",
                                                                                                    onClick: (e)=>handlePercentChange("SELL", 50),
                                                                                                    children: "50%"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-muted px-1 pointer",
                                                                                                    onClick: (e)=>handlePercentChange("SELL", 75),
                                                                                                    children: "75%"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-muted pointer",
                                                                                                    onClick: (e)=>handlePercentChange("SELL", 100),
                                                                                                    children: "100%"
                                                                                                })
                                                                                            ]
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        className: "input-group mb-3",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "input-group-text",
                                                                                                children: "Total"
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                                type: "text",
                                                                                                className: "form-control",
                                                                                                value: usdtInputSell,
                                                                                                onChange: (e)=>handleUsdtInputSellChange(e)
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "input-group-text",
                                                                                                children: "USDT"
                                                                                            })
                                                                                        ]
                                                                                    }),
                                                                                    errorSellSide !== undefined ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                        className: "text-danger m-2",
                                                                                        children: errorSellSide
                                                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                        children: "\xa0"
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                                                        disabled: loadingSell || errorSellSide !== undefined && errorSellSide.length > 0,
                                                                                        type: "button",
                                                                                        onClick: (e)=>handleSubmit(e, "SELL"),
                                                                                        className: "btn flex-fill btn-light-danger py-2 fs-5 text-uppercase px-5 w-100",
                                                                                        children: [
                                                                                            "                             ",
                                                                                            loadingSell ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                className: "d-flex align-items-center align-content-center ",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                        className: "spinner-border spinner-border-md"
                                                                                                    }),
                                                                                                    "SELL ",
                                                                                                    main_currency
                                                                                                ]
                                                                                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                                children: [
                                                                                                    " SELL ",
                                                                                                    main_currency,
                                                                                                    " "
                                                                                                ]
                                                                                            })
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: `tab-pane fade ${type == "MARKET" ? "show active" : ""}`,
                                                            id: "Market",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "row g-3",
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "col-lg-6",
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                className: "d-flex align-items-center justify-content-between my-3",
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                        className: "small text-muted",
                                                                                        children: "Avbl"
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                        className: "",
                                                                                        children: [
                                                                                            (0,_app_util_helpers__WEBPACK_IMPORTED_MODULE_10__/* .formatDecimal */ .VG)(usdtBalance, 5),
                                                                                            " USDT"
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                                                                children: [
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                                                        "data-trigger": "focus",
                                                                                        style: {
                                                                                            borderBottom: "1px dotted blue"
                                                                                        },
                                                                                        role: "button",
                                                                                        type: "button",
                                                                                        className: "mb-1",
                                                                                        id: "popBuy1",
                                                                                        "data-bs-toggle": "popover",
                                                                                        title: "Order Rules",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                                                                                children: "\xa0\xa0Price Rules"
                                                                                            }),
                                                                                            " "
                                                                                        ]
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        className: "input-group mb-3",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "input-group-text",
                                                                                                children: "Amount"
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                                type: "text",
                                                                                                className: "form-control",
                                                                                                value: btcInputBuyMarket,
                                                                                                onChange: (e)=>handleBtcInputBuyMarketChange(e)
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "input-group-text",
                                                                                                children: main_currency
                                                                                            })
                                                                                        ]
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                        className: "input-group mb-3",
                                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                            className: "mb-2 d-flex justify-content-between align-items-center w-100",
                                                                                            children: [
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-muted pointer",
                                                                                                    onClick: (e)=>handlePercentChange("BUY", 0),
                                                                                                    children: "0%"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-muted px-2 pointer",
                                                                                                    onClick: (e)=>handlePercentChange("BUY", 25),
                                                                                                    children: "25%"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-muted px-1 pointer",
                                                                                                    onClick: (e)=>handlePercentChange("BUY", 50),
                                                                                                    children: "50%"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-muted px-1 pointer",
                                                                                                    onClick: (e)=>handlePercentChange("BUY", 75),
                                                                                                    children: "75%"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-muted pointer",
                                                                                                    onClick: (e)=>handlePercentChange("BUY", 100),
                                                                                                    children: "100%"
                                                                                                })
                                                                                            ]
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        className: "input-group mb-3",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "input-group-text",
                                                                                                children: "Total"
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                                type: "text",
                                                                                                className: "form-control",
                                                                                                value: usdtInputBuyMarket,
                                                                                                onChange: (e)=>handleUsdtInputBuyMarketChange(e)
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "input-group-text",
                                                                                                children: "USDT"
                                                                                            })
                                                                                        ]
                                                                                    }),
                                                                                    errorBuySideMarket !== undefined ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                        className: "text-danger m-2",
                                                                                        children: errorBuySideMarket
                                                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                        children: "\xa0"
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                                                        disabled: loadingBuyMarket || errorBuySideMarket !== undefined && errorBuySideMarket.length > 0,
                                                                                        type: "button",
                                                                                        onClick: (e)=>handleSubmit(e, "BUY"),
                                                                                        className: "btn flex-fill btn-light-success py-2 fs-5 text-uppercase px-5 w-100",
                                                                                        children: [
                                                                                            "                             ",
                                                                                            loadingBuyMarket ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                className: "d-flex align-items-center align-content-center ",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                        className: "spinner-border spinner-border-md"
                                                                                                    }),
                                                                                                    "BUY ",
                                                                                                    main_currency
                                                                                                ]
                                                                                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                                children: [
                                                                                                    " BUY ",
                                                                                                    main_currency,
                                                                                                    " "
                                                                                                ]
                                                                                            })
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            })
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "col-lg-6",
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                className: "d-flex align-items-center justify-content-between my-3",
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                        className: "small text-muted",
                                                                                        children: "Avbl"
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                        className: "",
                                                                                        children: [
                                                                                            mainCoinBalance,
                                                                                            " ",
                                                                                            main_currency
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                                                                children: [
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                                                        "data-trigger": "focus",
                                                                                        style: {
                                                                                            borderBottom: "1px dotted blue"
                                                                                        },
                                                                                        role: "button",
                                                                                        type: "button",
                                                                                        className: "mb-1",
                                                                                        id: "popSell1",
                                                                                        "data-bs-toggle": "popover",
                                                                                        title: "Order Rules",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                                                                                children: "\xa0\xa0Price Rules"
                                                                                            }),
                                                                                            " "
                                                                                        ]
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        className: "input-group mb-3",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "input-group-text",
                                                                                                children: "Amount"
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                                type: "text",
                                                                                                className: "form-control",
                                                                                                value: btcInputSellMarket,
                                                                                                onChange: (e)=>handleBtcInputSellMarketChange(e)
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "input-group-text",
                                                                                                children: main_currency
                                                                                            })
                                                                                        ]
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                        className: "input-group mb-3",
                                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                            className: "mb-2 d-flex justify-content-between align-items-center w-100",
                                                                                            children: [
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-muted pointer",
                                                                                                    onClick: (e)=>handlePercentChange("SELL", 0),
                                                                                                    children: "0%"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-muted px-2 pointer",
                                                                                                    onClick: (e)=>handlePercentChange("SELL", 25),
                                                                                                    children: "25%"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-muted px-1 pointer",
                                                                                                    onClick: (e)=>handlePercentChange("SELL", 50),
                                                                                                    children: "50%"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-muted px-1 pointer",
                                                                                                    onClick: (e)=>handlePercentChange("SELL", 75),
                                                                                                    children: "75%"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                    className: "text-muted pointer",
                                                                                                    onClick: (e)=>handlePercentChange("SELL", 100),
                                                                                                    children: "100%"
                                                                                                })
                                                                                            ]
                                                                                        })
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        className: "input-group mb-3",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "input-group-text",
                                                                                                children: "Total"
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                                type: "text",
                                                                                                className: "form-control",
                                                                                                value: usdtInputSellMarket,
                                                                                                onChange: (e)=>handleUsdtInputSellMarketChange(e)
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "input-group-text",
                                                                                                children: "USDT"
                                                                                            })
                                                                                        ]
                                                                                    }),
                                                                                    errorSellSideMarket !== undefined ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                        className: "text-danger m-2",
                                                                                        children: errorSellSideMarket
                                                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                        children: "\xa0"
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                                                        disabled: loadingSellMarket || errorSellSideMarket !== undefined && errorSellSideMarket.length > 0,
                                                                                        type: "button",
                                                                                        onClick: (e)=>handleSubmit(e, "SELL"),
                                                                                        className: "btn flex-fill btn-light-danger py-2 fs-5 text-uppercase px-5 w-100",
                                                                                        children: [
                                                                                            "                             ",
                                                                                            loadingSellMarket ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                className: "d-flex align-items-center align-content-center ",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                        className: "spinner-border spinner-border-md"
                                                                                                    }),
                                                                                                    "SELL ",
                                                                                                    main_currency
                                                                                                ]
                                                                                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                                children: [
                                                                                                    " SELL ",
                                                                                                    main_currency,
                                                                                                    " "
                                                                                                ]
                                                                                            })
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-3",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "card",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "card-header py-3 d-flex justify-content-between bg-transparent border-bottom-0",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h6", {
                                            className: "mb-0 fw-bold ",
                                            children: [
                                                "Trades (",
                                                main_currency,
                                                " /USDT)"
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_app_components_trade__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        coin: main_currency
                                    })
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row g-3 mb-3",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-xxl-12",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "card",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "card-header py-3 d-flex justify-content-between bg-transparent border-bottom-0",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                        className: "mb-0 fw-bold ",
                                        children: "Order History"
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "card-body",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                            className: "nav nav-tabs tab-body-header rounded d-inline-flex mb-3",
                                            role: "tablist",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    className: "nav-item",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "nav-link active",
                                                        "data-bs-toggle": "tab",
                                                        href: "#OpenOrder",
                                                        role: "tab",
                                                        children: "Open Order(7)"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    className: "nav-item",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "nav-link",
                                                        "data-bs-toggle": "tab",
                                                        href: "#OrderHistory",
                                                        role: "tab",
                                                        children: "Order History"
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "tab-content",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "tab-pane fade show active",
                                                    id: "OpenOrder",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                                        id: "ordertabone",
                                                        className: "priceTable table table-hover custom-table-2 table-bordered align-middle mb-0",
                                                        style: {
                                                            width: "100%"
                                                        },
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                            children: "Date"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                            children: "Pair"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                            children: "Type"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                            children: "Side"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                            children: "Price"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                            children: "Amount"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                            children: "Action"
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                                children: orderList != undefined && orderList.length > 0 ? orderList.filter((v)=>{
                                                                    return v["status"] != "FILLED";
                                                                }).map((v)=>{
                                                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: v["created_at"]
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                        src: `assets/images/coin/${v["symbol"].substr(0, v["symbol"].indexOf("USDT"))}.png`,
                                                                                        alt: "s",
                                                                                        className: "img-fluid avatar mx-1"
                                                                                    }),
                                                                                    v["symbol"].substr(0, v["symbol"].indexOf("USDT")),
                                                                                    "/USDT"
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: v["type"]
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                    className: `color-price-${v["side"] == "SELL" ? "down" : "up"}`,
                                                                                    children: v["side"]
                                                                                })
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: v["settled_price"]
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: v["executedQty"]
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                    className: "btn-group",
                                                                                    role: "group",
                                                                                    children: [
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                            type: "button",
                                                                                            className: "btn btn-outline-secondary",
                                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                                                className: "icofont-edit text-success"
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                            type: "button",
                                                                                            className: "btn btn-outline-secondary deleterow",
                                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                                                className: "icofont-ui-delete text-danger"
                                                                                            })
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            })
                                                                        ]
                                                                    });
                                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                        colSpan: 7,
                                                                        style: {
                                                                            textAlign: "center"
                                                                        },
                                                                        children: "No orders"
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "tab-pane fade",
                                                    id: "OrderHistory",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                                        id: "ordertabtwo",
                                                        className: "priceTable table table-hover custom-table-2 table-bordered align-middle mb-0",
                                                        style: {
                                                            width: "100%"
                                                        },
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                            children: "Date"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                            children: "Pair"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                            children: "Type"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                            children: "Side"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                            children: "Average"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                            children: "Price"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                            children: "Executed"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                            children: "Amount"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                            children: "Total"
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                                children: orderList != undefined && orderList.length > 0 ? orderList.map((v)=>{
                                                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: v["created_at"]
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                        src: `assets/images/coin/${v["symbol"].substr(0, v["symbol"].indexOf("USDT"))}.png`,
                                                                                        alt: "s",
                                                                                        className: "img-fluid avatar mx-1"
                                                                                    }),
                                                                                    v["symbol"].substr(0, v["symbol"].indexOf("USDT")),
                                                                                    "/USDT"
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: v["type"]
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                    className: `color-price-${v["side"] == "SELL" ? "down" : "up"}`,
                                                                                    children: v["side"]
                                                                                })
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: v["settled_price"]
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: v["executedQty"]
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                    className: "btn-group",
                                                                                    role: "group",
                                                                                    children: [
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                            type: "button",
                                                                                            className: "btn btn-outline-secondary",
                                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                                                className: "icofont-edit text-success"
                                                                                            })
                                                                                        }),
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                            type: "button",
                                                                                            className: "btn btn-outline-secondary deleterow",
                                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                                                className: "icofont-ui-delete text-danger"
                                                                                            })
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            })
                                                                        ]
                                                                    });
                                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                        colSpan: 7,
                                                                        style: {
                                                                            textAlign: "center"
                                                                        },
                                                                        children: "No orders"
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 40654:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`E:\exchange\boottest\app\(exchange)\exchange\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [763,489,609,977,869,813,894,528,916,15,690,873], () => (__webpack_exec__(78618)));
module.exports = __webpack_exports__;

})();