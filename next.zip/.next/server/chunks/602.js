"use strict";
exports.id = 602;
exports.ids = [602];
exports.modules = {

/***/ 88602:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   L: () => (/* binding */ authOptions)
/* harmony export */ });
/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(38198);
/*eslint-disable*/ 
const authOptions = {
    session: {
        strategy: "jwt",
        maxAge: 24 * 60 * 60
    },
    pages: {
        signIn: "/auth/login",
        signOut: "/auth/login"
    },
    providers: [
        (0,next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            name: "Sign in",
            credentials: {
                email: {
                    label: "Email",
                    type: "email",
                    placeholder: "example@example.com"
                },
                password: {
                    label: "Password",
                    type: "password"
                }
            },
            async authorize (credentials) {
                const resp = await fetch("http://localhost:4000/auth/login", {
                    method: "POST",
                    mode: "cors",
                    credentials: "include",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(credentials)
                });
                const response = await resp.json();
                if (response.success) {
                    return response.data;
                } else {
                    return null;
                }
            }
        })
    ],
    callbacks: {
        async session ({ session, user, token }) {
            if (session?.user) session.user = token.user;
            return session;
        },
        async jwt ({ token, user, account, profile, isNewUser }) {
            if (user !== undefined) token.user = {
                ...token,
                ...user
            };
            return token;
        }
    }
};


/***/ })

};
;